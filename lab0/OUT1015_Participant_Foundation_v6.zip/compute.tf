locals {
  machines = {
    test = { subnet = "core_public", public = true, file = "tools-cloud-init.sh" }
    app  = { subnet = "core_private", public = false, file = "order-app-cloud-init.yaml" }
    web  = { subnet = "waf_public", public = true, file = "web-server-cloud-init.sh" }
  }
}
resource "oci_core_instance" "lab" {
  for_each            = local.machines
  compartment_id      = var.compartment_id
  availability_domain = var.availability_domain
  display_name        = "${local.prefix}-${each.key}"
  shape               = "VM.Standard.A1.Flex"
  shape_config {
    ocpus         = 1
    memory_in_gbs = 6
  }
  source_details {
    source_type             = "image"
    source_id               = var.image_id
    boot_volume_size_in_gbs = 50
  }
  create_vnic_details {
    subnet_id        = oci_core_subnet.lab[each.value.subnet].id
    assign_public_ip = each.value.public
    private_ip       = each.key == "app" ? local.app_private_ip : null
    hostname_label   = "summit-${each.key}"
    nsg_ids          = [oci_core_network_security_group.lab[each.key].id]
  }
  metadata = {
    ssh_authorized_keys = var.ssh_public_key
    user_data           = filebase64("${path.module}/bootstrap/${each.value.file}")
  }
  agent_config {
    are_all_plugins_disabled = false
    is_management_disabled   = false
    plugins_config {
      name          = "Bastion"
      desired_state = "ENABLED"
    }
  }
  preserve_boot_volume = false
  freeform_tags        = local.tags
  depends_on = [
    oci_core_network_security_group_security_rule.tcp,
    oci_core_network_security_group_security_rule.egress,
    oci_core_network_security_group_security_rule.icmp,
  ]
}
