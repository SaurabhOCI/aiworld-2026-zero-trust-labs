locals {
  nsgs = { test = "core", app = "core", orders_lb = "core", web = "waf", waf_lb = "waf" }
  tcp_rules = {
    test_ssh    = { nsg = "test", source = var.admin_cidr, kind = "CIDR_BLOCK", port = 22 }
    orders_http = { nsg = "orders_lb", source = "0.0.0.0/0", kind = "CIDR_BLOCK", port = 80 }
    waf_http    = { nsg = "waf_lb", source = "0.0.0.0/0", kind = "CIDR_BLOCK", port = 80 }
    app_http    = { nsg = "app", source = oci_core_network_security_group.lab["orders_lb"].id, kind = "NETWORK_SECURITY_GROUP", port = 8080 }
    web_http    = { nsg = "web", source = oci_core_network_security_group.lab["waf_lb"].id, kind = "NETWORK_SECURITY_GROUP", port = 80 }
    bastion_ssh = { nsg = "app", source = "${oci_bastion_bastion.lab.private_endpoint_ip_address}/32", kind = "CIDR_BLOCK", port = 22 }
  }
}
resource "oci_core_network_security_group" "lab" {
  for_each       = local.nsgs
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.lab[each.value].id
  display_name   = "${local.prefix}-${each.key}-nsg"
  freeform_tags  = local.tags
}
resource "oci_core_network_security_group_security_rule" "egress" {
  for_each                  = local.nsgs
  network_security_group_id = oci_core_network_security_group.lab[each.key].id
  direction                 = "EGRESS"
  protocol                  = "all"
  destination               = "0.0.0.0/0"
  destination_type          = "CIDR_BLOCK"
  stateless                 = false
  description               = "Workshop baseline outbound access"
}
resource "oci_core_network_security_group_security_rule" "tcp" {
  for_each                  = local.tcp_rules
  network_security_group_id = oci_core_network_security_group.lab[each.value.nsg].id
  direction                 = "INGRESS"
  protocol                  = "6"
  source                    = each.value.source
  source_type               = each.value.kind
  stateless                 = false
  description               = each.key
  tcp_options {
    destination_port_range {
      min = each.value.port
      max = each.value.port
    }
  }
}
resource "oci_core_network_security_group_security_rule" "icmp" {
  for_each                  = local.nsgs
  network_security_group_id = oci_core_network_security_group.lab[each.key].id
  direction                 = "INGRESS"
  protocol                  = "1"
  source                    = "0.0.0.0/0"
  source_type               = "CIDR_BLOCK"
  stateless                 = false
  description               = "Path MTU discovery"
  icmp_options {
    type = 3
    code = 4
  }
}
