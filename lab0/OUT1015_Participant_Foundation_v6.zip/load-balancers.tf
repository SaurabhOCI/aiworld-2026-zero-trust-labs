locals {
  backends = {
    orders = { network = "core_public", nsg = "orders_lb", vm = "app", port = 8080 }
    waf    = { network = "waf_public", nsg = "waf_lb", vm = "web", port = 80 }
  }
}
resource "oci_load_balancer_load_balancer" "lab" {
  for_each                     = local.backends
  compartment_id               = var.compartment_id
  display_name                 = "${local.prefix}-${each.key}-lb"
  shape                        = "flexible"
  is_private                   = false
  is_delete_protection_enabled = false
  subnet_ids                   = [oci_core_subnet.lab[each.value.network].id]
  network_security_group_ids   = [oci_core_network_security_group.lab[each.value.nsg].id]
  shape_details {
    minimum_bandwidth_in_mbps = 10
    maximum_bandwidth_in_mbps = 10
  }
  freeform_tags = local.tags
}
resource "oci_load_balancer_backend_set" "lab" {
  for_each         = local.backends
  load_balancer_id = oci_load_balancer_load_balancer.lab[each.key].id
  name             = "summit-${each.key}"
  policy           = "ROUND_ROBIN"
  health_checker {
    protocol          = "HTTP"
    port              = each.value.port
    url_path          = "/healthz"
    return_code       = 200
    interval_ms       = 10000
    timeout_in_millis = 3000
    retries           = 3
  }
}
resource "oci_load_balancer_backend" "lab" {
  for_each         = local.backends
  load_balancer_id = oci_load_balancer_load_balancer.lab[each.key].id
  backendset_name  = oci_load_balancer_backend_set.lab[each.key].name
  ip_address       = oci_core_instance.lab[each.value.vm].private_ip
  port             = each.value.port
}
resource "oci_load_balancer_listener" "lab" {
  for_each                 = local.backends
  load_balancer_id         = oci_load_balancer_load_balancer.lab[each.key].id
  name                     = "http"
  default_backend_set_name = oci_load_balancer_backend_set.lab[each.key].name
  port                     = 80
  protocol                 = "HTTP"
}
