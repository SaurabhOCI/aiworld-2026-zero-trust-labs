#!/bin/bash
# Prepare tools only. Learners create and retrieve their own synthetic secret.
set -euo pipefail
exec > >(tee -a /var/log/summit-tools-bootstrap.log) 2>&1
# Internet-wide workshop SSH still requires a key; no password login is enabled.
install -d -m 0755 /etc/ssh/sshd_config.d
cat > /etc/ssh/sshd_config.d/00-out1015-key-only.conf <<'SSH'
AuthenticationMethods publickey
PasswordAuthentication no
KbdInteractiveAuthentication no
SSH
/usr/sbin/sshd -t
systemctl reload sshd
dnf -y install --enablerepo=ol9_developer python39-oci-cli
oci --version
python3.9 -c 'import oci; print("OCI Python SDK ready:", oci.__version__)'
echo 'Summit tools VM ready'
