#!/bin/bash
# Paste this script into the instance's cloud-init/user-data field.
# Synthetic, static HTTP application: query strings are neither reflected nor executed.
set -euo pipefail
exec > >(tee -a /var/log/summit-retail-bootstrap.log) 2>&1
dnf -y install httpd
cat > /var/www/html/index.html <<'HTML'
<!doctype html>
<html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>Summit Retail | Product catalogue</title>
<style>
body{font:20px/1.5 system-ui,sans-serif;background:#f6f5ef;color:#203e35;margin:0}
main{max-width:850px;margin:70px auto;padding:30px}h1{font-size:46px;line-height:1.1}
article{background:white;padding:22px;margin:14px 0;border-left:5px solid #d98748}
small{font-size:15px}strong{float:right}
</style><main><small>SUMMIT RETAIL &middot; PARTICIPANT LAB</small>
<h1>Find your next everyday favourite.</h1>
<p>Our product catalogue is open for customers.</p>
<article>Everyday Backpack <strong>32 in stock</strong></article>
<article>Summit Phone <strong>24 in stock</strong></article>
<article>Travel Headphones <strong>18 in stock</strong></article>
<p><small>Synthetic workshop data. No sign-in or payment information.</small></p>
</main></html>
HTML
printf 'summit-retail-web: ok\n' > /var/www/html/healthz
if systemctl is-active --quiet firewalld; then
  firewall-cmd --permanent --add-service=http
  firewall-cmd --reload
fi
systemctl enable --now httpd
curl --fail --retry 5 --retry-connrefused http://127.0.0.1/healthz
echo 'Summit Retail web server ready'
