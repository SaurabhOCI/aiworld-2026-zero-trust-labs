output "workshop" {
  value = {
    compartment_id       = var.compartment_id
    region               = var.region
    participant          = var.participant
    prefix               = local.prefix
    tools_public_ip      = oci_core_instance.lab["test"].public_ip
    app_private_ip       = oci_core_instance.lab["app"].private_ip
    order_url            = "http://${one(oci_load_balancer_load_balancer.lab["orders"].ip_address_details).ip_address}"
    catalogue_url        = "http://${one(oci_load_balancer_load_balancer.lab["waf"].ip_address_details).ip_address}"
    instance_ids         = { for k, v in oci_core_instance.lab : k => v.id }
    lb_ids               = { for k, v in oci_load_balancer_load_balancer.lab : k => v.id }
    bastion_id           = oci_bastion_bastion.lab.id
    app_security_list_id = oci_core_security_list.lab["core_private"].id
    vcn_ids              = { for k, v in oci_core_vcn.lab : k => v.id }
    admin_cidr           = var.admin_cidr
  }
}
