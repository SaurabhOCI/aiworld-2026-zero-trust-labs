#!/usr/bin/env python3
"""OUT1015 participant foundation (Lab 0). Run in your own Cloud Shell.

Commands: prepare, plan, apply, status, destroy-plan, destroy.
No cloud call occurs when importing this module.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from datetime import datetime, timezone
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parent
LOCAL = ROOT / '.local'
INPUTS = LOCAL / 'inputs.tfvars.json'
ALLOWED = {
    'oci_core_vcn', 'oci_core_internet_gateway', 'oci_core_nat_gateway',
    'oci_core_service_gateway', 'oci_core_route_table', 'oci_core_security_list',
    'oci_core_subnet', 'oci_bastion_bastion', 'oci_core_network_security_group',
    'oci_core_network_security_group_security_rule', 'oci_core_instance',
    'oci_load_balancer_load_balancer', 'oci_load_balancer_backend_set',
    'oci_load_balancer_backend', 'oci_load_balancer_listener',
}

def run(args, capture=False):
    return subprocess.run(args, cwd=ROOT, check=True, universal_newlines=True,
                          stdout=subprocess.PIPE if capture else None).stdout

def require_cloud_shell():
    expected = {'OCI_CLI_AUTH': 'instance_obo_user', 'OCI_AUTH': 'InstancePrincipal',
                'OCI_use_obo_token': 'true'}
    if any(os.environ.get(k) != v for k, v in expected.items()):
        raise ValueError('Use a fresh participant Cloud Shell with its delegated authentication. No API-key fallback is supported.')
    if not all(os.environ.get(k) for k in ('OCI_CLI_CONFIG_FILE', 'OCI_CLI_PROFILE')):
        raise ValueError('Cloud Shell CLI configuration is missing.')

def cli(*args):
    return json.loads(run(['oci', '--config-file', os.environ['OCI_CLI_CONFIG_FILE'],
        '--profile', os.environ['OCI_CLI_PROFILE'], '--auth', 'instance_obo_user',
        '--region', region(), '--connection-timeout', '10', '--read-timeout', '60',
        '--max-retries', '0', *args, '--output', 'json'], capture=True))['data']

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')
    path.chmod(0o600)

def inputs():
    if not INPUTS.exists():
        raise ValueError('Run prepare first.')
    values = json.loads(INPUTS.read_text())
    if not values.get('participant'):
        raise ValueError('These inputs come from an older pilot package. Keep using that package to manage its deployment.')
    return values

def region():
    if INPUTS.exists():
        return json.loads(INPUTS.read_text()).get('region', 'us-ashburn-1')
    return os.environ.get('OCI_REGION') or 'us-ashburn-1'

def suggest(user_name):
    """'98507690-lab.user07' -> ('user07', '98507690-C07'); (None, None) if no match."""
    match = re.match(r'^(?P<lab>[A-Za-z0-9]+)-lab\.user(?P<nn>[0-9]{2})$', user_name or '')
    if not match:
        return None, None
    return 'user' + match['nn'], f"{match['lab']}-C{match['nn']}"

def ask(prompt, default, given=None):
    if given:
        return given.strip()
    answer = input(f'{prompt} [{default}]: ' if default else f'{prompt}: ').strip()
    return answer or (default or '')

def prepare(opts):
    if INPUTS.exists():
        raise ValueError('Inputs already exist. Keep this deployment directory; do not regenerate keys or inputs. Continue with plan.')
    user_name = None
    if os.environ.get('OCI_CS_USER_OCID'):
        user_name = cli('iam', 'user', 'get', '--user-id', os.environ['OCI_CS_USER_OCID'])['name']
        print('Signed-in user:', user_name)
    guess_participant, guess_compartment = suggest(user_name)
    participant = ask('Participant number (userNN)', guess_participant, opts.participant)
    if not re.match(r'^user[0-9]{2}$', participant):
        raise ValueError('Participant must look like user07.')
    name = ask('Your assigned compartment name', guess_compartment, opts.compartment)
    tenancy = os.environ.get('OCI_TENANCY')
    if not tenancy:
        raise ValueError('Cloud Shell did not provide the tenancy OCID (OCI_TENANCY).')
    found = [c for c in cli('iam', 'compartment', 'list', '--compartment-id', tenancy,
             '--compartment-id-in-subtree', 'true', '--access-level', 'ACCESSIBLE',
             '--name', name, '--all') if c['lifecycle-state'] == 'ACTIVE']
    if len(found) != 1:
        raise ValueError(f'Expected exactly one active compartment named {name}; found {len(found)}. Check the name in your lab details.')
    cid = found[0]['id']
    print(f'Compartment: {name}  Resource names: out1015-{participant}-...  Region: {region()}')
    print('One-day workshop: Tools VM SSH and Bastion client access use 0.0.0.0/0; SSH keys are required. Destroy the lab after use; access has no automatic daily expiry.')
    ads = cli('iam', 'availability-domain', 'list', '--compartment-id', cid)
    if not ads:
        raise ValueError('No availability domains returned.')
    for i, ad in enumerate(ads, 1):
        print(f'{i}: {ad["name"]}')
    index = int(ask('Availability domain number', '1', opts.ad)) - 1
    if index < 0 or index >= len(ads):
        raise ValueError('Invalid availability domain selection.')
    images = cli('compute', 'image', 'list', '--compartment-id', cid,
        '--operating-system', 'Oracle Linux', '--operating-system-version', '9',
        '--shape', 'VM.Standard.A1.Flex', '--sort-by', 'TIMECREATED',
        '--sort-order', 'DESC', '--limit', '1')
    if not images:
        raise ValueError('No compatible Oracle Linux 9 A1 image returned.')
    image = images[0]
    key = LOCAL / 'workshop_ssh'
    if not key.exists():
        if key.with_suffix('.pub').exists():
            raise ValueError('An unmatched public key exists; inspect it before continuing.')
        # Cloud Shell can enforce FIPS mode, where Ed25519 generation is rejected.
        run(['ssh-keygen', '-q', '-t', 'rsa', '-b', '3072', '-N', '', '-C', 'out1015-' + participant, '-f', str(key)])
    public_key = run(['ssh-keygen', '-y', '-f', str(key)], capture=True).strip()
    key.chmod(0o600)
    write_json(INPUTS, dict(compartment_id=cid, participant=participant, region=region(),
        availability_domain=ads[index]['name'], image_id=image['id'],
        ssh_public_key=public_key, admin_cidr='0.0.0.0/0'))
    write_json(LOCAL / 'selection.json', {'compartment_name': name, 'participant': participant,
        'image_name': image['display-name'], 'image_id': image['id'],
        'availability_domain': ads[index]['name'], 'shape': 'VM.Standard.A1.Flex',
        'selected_at': datetime.now(timezone.utc).isoformat()})
    print(f'Selected image: {image["display-name"]}')
    print('Prepared 3 x A1 (1 OCPU / 6 GB / 50 GB boot), two 10 Mbps LBs and networking.')
    print(f'SSH private key stays in Cloud Shell: {key}')
    print('No infrastructure created. Next: python3 lab.py plan')

def tf(*args, capture=False):
    return run(['terraform', *args], capture=capture)

def fingerprint():
    paths = sorted(ROOT.glob('*.tf')) + sorted((ROOT / 'bootstrap').glob('*'))
    paths += [INPUTS, ROOT / '.terraform.lock.hcl']
    digest = hashlib.sha256()
    for p in paths:
        digest.update(str(p.relative_to(ROOT)).encode())
        digest.update(p.read_bytes())
    return digest.hexdigest()

def validate_changes(plan, destroying=False, cid=None):
    cid = cid or inputs()['compartment_id']
    counts = {'create': 0, 'update': 0, 'delete': 0}
    for resource in plan.get('resource_changes', []):
        if resource.get('mode') != 'managed':
            continue
        if resource['type'] not in ALLOWED:
            raise ValueError('Unexpected resource type in plan: ' + resource['type'])
        actions = resource['change']['actions']
        valid = (['delete'], ['no-op']) if destroying else (['create'], ['no-op'])
        if actions not in valid:
            raise ValueError(f'Refusing {actions} for {resource["address"]}. This lab allows initial creation or explicit cleanup; no repair/replacement or re-Apply of learning edits.')
        for side in ('before', 'after'):
            values = resource['change'].get(side) or {}
            if values.get('compartment_id') and values['compartment_id'] != cid:
                raise ValueError('Unexpected compartment in plan.')
        for action in actions:
            if action in counts:
                counts[action] += 1
    return counts

def plan(destroying=False):
    inputs()
    mode = 'destroy' if destroying else 'apply'
    previous_receipt = LOCAL / f'{mode}-approval.json'
    if previous_receipt.exists():
        previous_receipt.unlink()
    tf('init', '-input=false', '-no-color')
    tf('validate', '-no-color')
    args = ['plan', '-input=false', '-no-color', '-var-file=.local/inputs.tfvars.json',
            '-out=.local/' + mode + '.tfplan']
    if destroying:
        args.append('-destroy')
    tf(*args)
    saved = LOCAL / (mode + '.tfplan')
    details = json.loads(tf('show', '-json', str(saved), capture=True))
    counts = validate_changes(details, destroying)
    write_json(LOCAL / f'{mode}-approval.json', {'config_hash': fingerprint(),
        'plan_hash': hashlib.sha256(saved.read_bytes()).hexdigest(), 'counts': counts})
    print('Reviewed plan scope:', json.dumps(counts))
    print('No changes applied. Next command after reviewing this plan: python3 lab.py ' + mode)

def execute_plan(destroying=False):
    mode = 'destroy' if destroying else 'apply'
    receipt = LOCAL / f'{mode}-approval.json'
    if not receipt.exists():
        raise ValueError('No checked plan. Run ' + ('destroy-plan' if destroying else 'plan') + ' first.')
    saved = LOCAL / (mode + '.tfplan')
    proof = json.loads(receipt.read_text())
    if fingerprint() != proof['config_hash'] or hashlib.sha256(saved.read_bytes()).hexdigest() != proof['plan_hash']:
        raise ValueError('Configuration or plan changed. Generate and review a fresh plan.')
    if destroying:
        print('Remove learner-created WAF attachments and active Bastion sessions first; follow README cleanup.')
        prefix = 'out1015-' + inputs()['participant']
        if input(f'Type {prefix} to destroy this lab infrastructure: ') != prefix:
            raise ValueError('Cleanup cancelled.')
    # Consume receipt even if apply fails: preserve state and generate a fresh plan.
    receipt.unlink()
    tf('apply', '-input=false', '-no-color', str(saved))
    if not destroying:
        print('Infrastructure apply completed; bootstrap and application health still need verification.')
        status()
    else:
        remaining = tf('state', 'list', capture=True).strip()
        if any(line.startswith('oci_') for line in remaining.splitlines()):
            raise ValueError('Managed resources remain in state. Cleanup is not complete.')
        print('No Terraform-managed resources remain in this lab state. Separately verify any learner-created resources.')

def status():
    outputs = json.loads(tf('output', '-json', 'workshop', capture=True))
    write_json(LOCAL / 'outputs.json', outputs)
    print(json.dumps(outputs, indent=2))
    good = True
    for label, key, expected in [('Orders', 'order_url', 'summit-order-app: ok'),
                                 ('Catalogue', 'catalogue_url', 'summit-retail-web: ok')]:
        try:
            with urlopen(outputs[key] + '/healthz', timeout=15) as response:
                body = response.read(256).decode().strip()
                healthy = response.status == 200 and body == expected
                print(f'{label}: HTTP {response.status}; expected body matched: {healthy}')
                good = good and healthy
        except Exception as error:
            print(f'{label}: not verified ({type(error).__name__}). Check LB health and cloud-init; retry status when ready.')
            good = False
    print('HTTP checks passed.' if good else 'HTTP checks incomplete; Terraform completion alone is not application readiness.')
    print('Still required: tools VM bootstrap/SSH, VM secret retrieval, Bastion session and direct-block comparison; see README.')

def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('action', choices=['prepare', 'plan', 'apply', 'status', 'destroy-plan', 'destroy'])
    parser.add_argument('--participant', help='prepare: userNN, if it cannot be read from your user name')
    parser.add_argument('--compartment', help='prepare: assigned compartment name, for example 98507690-C07')
    parser.add_argument('--ad', help='prepare: availability domain number (default 1)')
    opts = parser.parse_args()
    os.umask(0o077)
    require_cloud_shell()
    LOCAL.mkdir(exist_ok=True, mode=0o700)
    action = opts.action
    if action == 'prepare': prepare(opts)
    elif action == 'plan': plan()
    elif action == 'destroy-plan': plan(True)
    elif action == 'apply': execute_plan()
    elif action == 'destroy': execute_plan(True)
    else: status()

if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError, subprocess.CalledProcessError) as error:
        print('STOP:', error, file=sys.stderr)
        print('Preserve this directory and .local state. No automatic cleanup or credential fallback was attempted.', file=sys.stderr)
        sys.exit(1)
