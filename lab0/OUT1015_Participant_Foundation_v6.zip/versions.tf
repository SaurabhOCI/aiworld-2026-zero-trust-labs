terraform {
  required_version = ">= 1.5.0, < 2.0.0"
  required_providers {
    oci = {
      source  = "oracle/oci"
      version = "= 7.32.0"
    }
  }
  backend "local" {
    path = ".local/terraform.tfstate"
  }
}

# Cloud Shell supplies delegated user authentication. No API keys are packaged.
provider "oci" {
  region = var.region
}

variable "compartment_id" {
  type = string
  validation {
    condition     = startswith(var.compartment_id, "ocid1.compartment.")
    error_message = "Use the OCID of your assigned compartment (ocid1.compartment...)."
  }
}
variable "participant" {
  type        = string
  description = "Participant number from the lab account, for example user07. Used in every resource name."
  validation {
    condition     = can(regex("^user[0-9]{2}$", var.participant))
    error_message = "Use the form userNN, for example user07."
  }
}
variable "region" {
  type    = string
  default = "us-ashburn-1"
}
variable "availability_domain" { type = string }
variable "image_id" { type = string }
variable "ssh_public_key" { type = string }
variable "admin_cidr" {
  type    = string
  default = "0.0.0.0/0"
  validation {
    condition     = var.admin_cidr == "0.0.0.0/0" || (can(cidrnetmask(var.admin_cidr)) && endswith(var.admin_cidr, "/32") && var.admin_cidr != "0.0.0.0/32")
    error_message = "Use the accepted workshop source 0.0.0.0/0 or an individual IPv4 /32."
  }
}

locals {
  prefix = "out1015-${var.participant}"
  tags   = { Workshop = "OUT1015", Purpose = "participant-foundation", Participant = var.participant, ManagedBy = "Terraform" }
}
