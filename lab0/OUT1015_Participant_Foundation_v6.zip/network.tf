locals {
  networks = {
    core = "10.42.0.0/16"
    waf  = "10.44.0.0/16"
  }
  subnets = {
    core_public  = { network = "core", cidr = "10.42.0.0/24", private = false }
    core_private = { network = "core", cidr = "10.42.1.0/24", private = true }
    waf_public   = { network = "waf", cidr = "10.44.0.0/24", private = false }
  }
  # Shared by the app VNIC and Bastion egress, known before resource creation.
  app_private_ip = cidrhost(local.subnets.core_private.cidr, 207)
}

resource "oci_core_vcn" "lab" {
  for_each       = local.networks
  compartment_id = var.compartment_id
  display_name   = "${local.prefix}-${each.key}-vcn"
  cidr_blocks    = [each.value]
  dns_label      = each.key
  freeform_tags  = local.tags
}
resource "oci_core_internet_gateway" "lab" {
  for_each       = local.networks
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.lab[each.key].id
  display_name   = "${local.prefix}-${each.key}-igw"
  enabled        = true
  freeform_tags  = local.tags
}
resource "oci_core_nat_gateway" "core" {
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.lab["core"].id
  display_name   = "${local.prefix}-core-nat"
  freeform_tags  = local.tags
}
data "oci_core_services" "all" {
  filter {
    name   = "name"
    values = ["All .* Services In Oracle Services Network"]
    regex  = true
  }
}
resource "oci_core_service_gateway" "core" {
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.lab["core"].id
  display_name   = "${local.prefix}-core-services"
  services { service_id = one(data.oci_core_services.all.services).id }
  freeform_tags = local.tags
}
resource "oci_core_route_table" "public" {
  for_each       = local.networks
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.lab[each.key].id
  display_name   = "${local.prefix}-${each.key}-public-routes"
  route_rules {
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
    network_entity_id = oci_core_internet_gateway.lab[each.key].id
  }
  freeform_tags = local.tags
}
resource "oci_core_route_table" "private" {
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.lab["core"].id
  display_name   = "${local.prefix}-core-private-routes"
  route_rules {
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
    network_entity_id = oci_core_nat_gateway.core.id
  }
  route_rules {
    destination       = one(data.oci_core_services.all.services).cidr_block
    destination_type  = "SERVICE_CIDR_BLOCK"
    network_entity_id = oci_core_service_gateway.core.id
  }
  freeform_tags = local.tags
}

# Dedicated lists: ingress stays in NSGs; Bastion needs subnet-level SSH egress.
resource "oci_core_security_list" "lab" {
  for_each       = local.subnets
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.lab[each.value.network].id
  display_name   = "${local.prefix}-${each.key}-security-list"
  # The Bastion private endpoint does not inherit the app VM's NSG egress.
  # A planned app address permits exact /32 egress without a VM dependency cycle.
  dynamic "egress_security_rules" {
    for_each = each.key == "core_private" ? ["${local.app_private_ip}/32"] : []
    content {
      destination      = egress_security_rules.value
      destination_type = "CIDR_BLOCK"
      protocol         = "6"
      stateless        = false
      description      = "Allow Bastion outbound SSH to private app"
      tcp_options {
        min = 22
        max = 22
      }
    }
  }
  freeform_tags = local.tags
}
resource "oci_core_subnet" "lab" {
  for_each                   = local.subnets
  compartment_id             = var.compartment_id
  vcn_id                     = oci_core_vcn.lab[each.value.network].id
  display_name               = "${local.prefix}-${each.key}"
  cidr_block                 = each.value.cidr
  dns_label                  = replace(each.key, "_", "")
  prohibit_public_ip_on_vnic = each.value.private
  route_table_id             = each.value.private ? oci_core_route_table.private.id : oci_core_route_table.public[each.value.network].id
  security_list_ids          = [oci_core_security_list.lab[each.key].id]
  freeform_tags              = local.tags
}

resource "oci_bastion_bastion" "lab" {
  bastion_type                 = "STANDARD"
  compartment_id               = var.compartment_id
  target_subnet_id             = oci_core_subnet.lab["core_private"].id
  name                         = "out1015${var.participant}bastion"
  client_cidr_block_allow_list = [var.admin_cidr]
  max_session_ttl_in_seconds   = 3600
  freeform_tags                = local.tags
}
