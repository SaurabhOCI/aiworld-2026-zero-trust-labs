"""Offline tests: no credentials, CLI execution or cloud calls."""
import unittest
import tempfile
import json
from pathlib import Path
from unittest.mock import patch
import lab

CID = 'ocid1.compartment.oc1..assigned'

class PlanGuards(unittest.TestCase):
    def resource(self, actions, kind='oci_core_vcn', compartment=CID):
        return {'resource_changes': [{'mode': 'managed', 'type': kind,
            'address': 'oci_core_vcn.lab["core"]',
            'change': {'actions': actions, 'before': None,
                       'after': {'compartment_id': compartment}}}]}

    def test_create(self):
        self.assertEqual(lab.validate_changes(self.resource(['create']), cid=CID)['create'], 1)

    def test_replacement_refused(self):
        with self.assertRaises(ValueError):
            lab.validate_changes(self.resource(['delete', 'create']), cid=CID)

    def test_teaching_rule_update_refused(self):
        with self.assertRaises(ValueError):
            lab.validate_changes(self.resource(['update'], 'oci_core_security_list'), cid=CID)

    def test_foreign_compartment_refused(self):
        with self.assertRaises(ValueError):
            lab.validate_changes(self.resource(['create'], compartment='another-compartment'), cid=CID)

    def test_iam_and_waf_outside_foundation(self):
        for kind in ('oci_identity_policy', 'oci_waf_web_app_firewall_policy'):
            with self.assertRaises(ValueError):
                lab.validate_changes(self.resource(['create'], kind), cid=CID)

    def test_destroy_must_not_create(self):
        with self.assertRaises(ValueError):
            lab.validate_changes(self.resource(['create']), True, cid=CID)

    def test_destroy_rejects_foreign_before(self):
        plan = self.resource(['delete'])
        change = plan['resource_changes'][0]['change']
        change['before'] = {'compartment_id': 'another-compartment'}
        change['after'] = None
        with self.assertRaises(ValueError):
            lab.validate_changes(plan, True, cid=CID)

    def test_destroy_allowed(self):
        self.assertEqual(lab.validate_changes(self.resource(['delete']), True, cid=CID)['delete'], 1)

    def test_no_mac_api_key_fallback(self):
        with patch.dict(lab.os.environ, {'OCI_CLI_AUTH': 'api_key'}, clear=True):
            with self.assertRaises(ValueError):
                lab.require_cloud_shell()

    def test_participant_from_user_name(self):
        self.assertEqual(lab.suggest('98507690-lab.user07'), ('user07', '98507690-C07'))
        self.assertEqual(lab.suggest('98507690-lab.user01'), ('user01', '98507690-C01'))

    def test_unknown_user_name_gives_no_guess(self):
        for name in ('saurabh', None, '98507690-lab.user7', 'x-lab.user123'):
            self.assertEqual(lab.suggest(name), (None, None))

    def test_old_pilot_inputs_refused(self):
        with tempfile.TemporaryDirectory() as folder:
            old = Path(folder) / 'inputs.tfvars.json'
            old.write_text(json.dumps({'compartment_id': CID}))
            with patch.object(lab, 'INPUTS', old):
                with self.assertRaises(ValueError):
                    lab.inputs()

    def test_names_follow_participant(self):
        tf = (Path(lab.ROOT) / 'versions.tf').read_text() + (Path(lab.ROOT) / 'network.tf').read_text()
        self.assertIn('prefix = "out1015-${var.participant}"', tf)
        self.assertIn('"out1015${var.participant}bastion"', tf)
        self.assertNotIn('user01', tf)

if __name__ == '__main__':
    unittest.main()
