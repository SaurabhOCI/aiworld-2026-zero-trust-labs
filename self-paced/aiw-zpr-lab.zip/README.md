# Self-paced lab: protect the business path with Zero Trust Packet Routing

Run in OCI Cloud Shell, in the region you want the lab in:

    python3 lab.py build        # about 25 minutes; add --enable-zpr if ZPR is not enabled yet
    python3 lab.py status
    python3 lab.py check        # Test VM -> database port
    python3 lab.py reset
    python3 lab.py teardown --yes

Follow the activity guide OUT1015_SelfPaced_ZPR_Activity_Guide. All data is synthetic.
