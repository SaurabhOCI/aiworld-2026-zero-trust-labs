#!/usr/bin/env python3
"""Read-only Summit Retail demonstration; every request opens a fresh DB connection."""
import html
import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import oracledb


def products():
    params = oracledb.ConnectParams(
        host=os.environ['DB_HOST'], port=1521, service_name='FREEPDB1',
        tcp_connect_timeout=5, retry_count=0,
    )
    with oracledb.connect(user='SUMMIT_APP', password=os.environ['DB_PASSWORD'], params=params) as con:
        con.call_timeout = 5000
        with con.cursor() as cur:
            cur.execute('SELECT product_name, stock FROM summit_data.products ORDER BY product_name')
            return [{'product': name, 'stock': stock} for name, stock in cur]


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = self.path.split('?', 1)[0]
        if path == '/healthz':
            return self.reply(200, 'summit-zpr-app: ok\n', 'text/plain')
        if path not in ('/', '/dbcheck', '/dbcheck.php'):
            return self.reply(404, 'Not found\n', 'text/plain')
        try:
            rows = products()
        except oracledb.Error:
            return self.reply(503, 'Database connection unavailable.\n', 'text/plain')
        if path != '/':
            return self.reply(200, json.dumps({'status': 'DB connection successful', 'products': rows}) + '\n', 'application/json')
        cards = ''.join(f'<article><h2>{html.escape(row["product"])}</h2><p>{row["stock"]} available</p></article>' for row in rows)
        page = '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Summit Retail</title><style>body{margin:0;background:#f6f5ee;color:#183e33;font:20px system-ui}main{max-width:940px;margin:8vh auto;padding:32px}small{letter-spacing:.15em}h1{font-size:52px;line-height:1.1}section{display:flex;gap:24px;flex-wrap:wrap}article{background:white;padding:24px;border-radius:16px;min-width:210px}h2{font-size:24px}.ok{background:#d9eddf;padding:18px;border-radius:10px}footer{font-size:14px;margin-top:40px;color:#50665c}</style>
<main><small>SUMMIT RETAIL</small><h1>Your next order starts here.</h1><p class="ok">DB connection successful — the application retrieved these products.</p><section>''' + cards + '''</section><footer>Workshop demonstration · Synthetic products only · Refresh to run a new database query.</footer></main></html>'''
        self.reply(200, page, 'text/html')

    def reply(self, status, body, kind):
        data = body.encode()
        self.send_response(status)
        self.send_header('Content-Type', kind + '; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt, *args):
        print('HTTP', self.command, self.path.split('?', 1)[0], flush=True)


if __name__ == '__main__':
    ThreadingHTTPServer(('0.0.0.0', 80), Handler).serve_forever()
