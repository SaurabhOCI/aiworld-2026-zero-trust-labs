#!/bin/bash
set -euo pipefail
umask 022
exec > /var/log/summit-zpr-bootstrap.log 2>&1
dnf -y install python3 python3-pip
useradd --system --no-create-home --shell /sbin/nologin summitzpr
python3 -m venv /opt/summit-zpr/venv
/opt/summit-zpr/venv/bin/pip install --disable-pip-version-check oracledb==3.4.0
chmod 755 /opt/summit-zpr /opt/summit-zpr/venv
chmod 644 /opt/summit-zpr/app.py
cat > /etc/systemd/system/summit-zpr-app.service <<'SERVICE'
[Unit]
Description=Summit Retail ZPR read-only demonstration
After=network-online.target
Wants=network-online.target
[Service]
User=summitzpr
Group=summitzpr
EnvironmentFile=/etc/summit-zpr.env
ExecStart=/opt/summit-zpr/venv/bin/python /opt/summit-zpr/app.py
Restart=on-failure
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
[Install]
WantedBy=multi-user.target
SERVICE
if systemctl is-active --quiet firewalld; then
  firewall-cmd --permanent --add-service=http
  firewall-cmd --reload
fi
systemctl daemon-reload
systemctl enable --now summit-zpr-app
curl --retry 10 --retry-connrefused --retry-delay 1 --fail http://127.0.0.1/healthz
echo 'Summit ZPR application ready'
