#!/usr/bin/env python3
"""Self-paced ZPR lab: build the Summit Retail starting state in YOUR OWN tenancy.

Run in OCI Cloud Shell from this folder (uses your Cloud Shell sign-in; no API key needed):

    python3 lab.py build              # about 25 minutes: network, 3 VMs, load balancer, ZPR namespace
    python3 lab.py status             # read-only: labels, policies, customer query, Test VM -> database port
    python3 lab.py check              # run only the Test VM -> database port test
    python3 lab.py reset              # remove your four labels and your business policy (back to the start)
    python3 lab.py teardown --yes     # delete everything this lab created

Options for build:
    --parent <compartment-OCID>   create the lab compartment here (default: tenancy root)
    --enable-zpr                  enable Zero Trust Packet Routing for the tenancy if it is not enabled yet

Everything lives in one new compartment, aiw-zpr-lab (tag aiw-lab=zpr), plus one ZPR namespace
and one ZPR administration policy. Private state (SSH key, database password, Terraform state)
stays in .local/ next to this script.
"""
import argparse
import json
import os
import secrets
import shutil
import string
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

import oci

HERE = Path(__file__).resolve().parent
LOCAL = HERE / '.local'
SETTINGS = LOCAL / 'settings.json'
TFVARS = LOCAL / 'terraform.tfvars.json'
KEY = LOCAL / 'lab_ssh'
TAG_KEY, TAG_VALUE = 'aiw-lab', 'zpr'
COMPARTMENT = 'aiw-zpr-lab'


def say(msg):
    print(f'[{time.strftime("%H:%M:%S")}] {msg}', flush=True)


def private_write(path, text):
    LOCAL.mkdir(mode=0o700, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'w') as f:
        f.write(text)


def load_settings():
    return json.loads(SETTINGS.read_text()) if SETTINGS.exists() else {}


# ---------------------------------------------------------------- OCI sign-in
def oci_auth(region=None):
    """Cloud Shell delegation token by default; AIW_OCI_CONFIG/AIW_OCI_PROFILE select an API-key profile."""
    if os.environ.get('AIW_OCI_CONFIG'):
        cfg = oci.config.from_file(os.environ['AIW_OCI_CONFIG'], os.environ.get('AIW_OCI_PROFILE', 'DEFAULT'))
        if region:
            cfg['region'] = region
        return cfg, {}
    if not os.environ.get('OCI_CLI_CONFIG_FILE'):
        sys.exit('Run this in OCI Cloud Shell (or set AIW_OCI_CONFIG to an API-key config file).')
    cfg = oci.config.from_file(os.environ['OCI_CLI_CONFIG_FILE'], os.environ.get('OCI_CLI_PROFILE', 'DEFAULT'))
    token = Path(cfg['delegation_token_file']).read_text().strip()
    cfg['region'] = region or os.environ.get('OCI_REGION') or cfg.get('region')
    return cfg, {'signer': oci.auth.signers.InstancePrincipalsDelegationTokenSigner(delegation_token=token)}


class Cloud:
    def __init__(self, region=None, home=None):
        self.cfg, kw = oci_auth(region)
        self.region = self.cfg['region']
        self.tenancy = self.cfg['tenancy']
        self.iam = oci.identity.IdentityClient(self.cfg, **kw)
        if not home:
            subs = self.iam.list_region_subscriptions(self.tenancy).data
            home = [s.region_name for s in subs if s.is_home_region][0]
        self.home = home
        home_cfg = dict(self.cfg, region=home)
        self.iam_home = oci.identity.IdentityClient(home_cfg, **kw)
        self.zpr = oci.zpr.ZprClient(home_cfg, **kw)
        self.compute = oci.core.ComputeClient(self.cfg, **kw)
        self.vn = oci.core.VirtualNetworkClient(self.cfg, **kw)
        self.lb = oci.load_balancer.LoadBalancerClient(self.cfg, **kw)


# ---------------------------------------------------------------- Terraform
def terraform(*args, capture=False):
    if not shutil.which('terraform'):
        sys.exit('Terraform is not installed here. Cloud Shell includes it; run this lab in Cloud Shell.')
    env = dict(os.environ, TF_IN_AUTOMATION='1')
    if os.environ.get('AIW_OCI_CONFIG'):  # API-key testing outside Cloud Shell
        cfg = oci.config.from_file(os.environ['AIW_OCI_CONFIG'], os.environ.get('AIW_OCI_PROFILE', 'DEFAULT'))
        env.update(OCI_TENANCY_OCID=cfg['tenancy'], OCI_USER_OCID=cfg['user'],
                   OCI_FINGERPRINT=cfg['fingerprint'], OCI_PRIVATE_KEY_PATH=cfg['key_file'])
    cmd = ['terraform', f'-chdir={HERE}', *args]
    p = subprocess.run(cmd, env=env, text=True, capture_output=capture)
    if p.returncode != 0:
        if capture:
            print(p.stdout[-3000:], p.stderr[-3000:])
        sys.exit(f'terraform {args[0]} failed (exit {p.returncode}). Fix the message above and rerun the same command; it resumes.')
    return p.stdout if capture else ''


def outputs():
    try:
        return json.loads(terraform('output', '-json', 'lab', capture=True))
    except (SystemExit, json.JSONDecodeError):
        return None


# ---------------------------------------------------------------- build
def prepare(cloud, parent):
    s = load_settings()
    if s and parent and s.get('parent') != parent:
        sys.exit('This lab was already prepared with another --parent; run teardown first.')
    if s and TFVARS.exists():
        return s
    parent = parent or cloud.tenancy
    ad = cloud.iam.list_availability_domains(cloud.tenancy).data[0].name
    shapes = {x.shape for x in cloud.compute.list_shapes(cloud.tenancy, availability_domain=ad).data}
    shape = next((x for x in ['VM.Standard.E5.Flex', 'VM.Standard.E4.Flex', 'VM.Standard3.Flex'] if x in shapes), None)
    if not shape:
        sys.exit('No suitable x86 flexible shape (E5, E4 or Standard3) is offered in this region.')
    images = cloud.compute.list_images(cloud.tenancy, operating_system='Oracle Linux', operating_system_version='9',
                                       shape=shape, sort_by='TIMECREATED', sort_order='DESC').data
    images = [i for i in images if 'aarch64' not in i.display_name and 'GPU' not in i.display_name]
    if not images:
        sys.exit('No Oracle Linux 9 image found for ' + shape)
    s = {'region': cloud.region, 'home_region': cloud.home, 'tenancy': cloud.tenancy, 'parent': parent,
         'availability_domain': ad, 'shape': shape, 'image_id': images[0].id, 'image': images[0].display_name,
         'namespace': 'aiwzpr' + ''.join(secrets.choice(string.ascii_lowercase + string.digits) for _ in range(6))}
    private_write(SETTINGS, json.dumps(s, indent=2))
    if not (KEY.exists() and KEY.with_suffix('.pub').exists()):
        make_ssh_key()
    password = ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(28))
    private_write(TFVARS, json.dumps({
        'region': s['region'], 'home_region': s['home_region'], 'tenancy_id': s['tenancy'],
        'parent_compartment_id': parent, 'availability_domain': ad, 'image_id': s['image_id'], 'shape': shape,
        'ssh_public_key': (KEY.with_suffix('.pub')).read_text().strip(), 'namespace': s['namespace'],
        'database_password': password}, indent=2))
    say(f"Prepared: region {s['region']} (home {s['home_region']}), {shape}, image {s['image']}, namespace {s['namespace']}")
    return s


def make_ssh_key():
    """RSA 3072: Cloud Shell runs OpenSSH in FIPS mode, which refuses Ed25519 keys."""
    for f in (KEY, KEY.with_suffix('.pub')):  # a half-written key from an interrupted run
        f.unlink(missing_ok=True)
    if shutil.which('ssh-keygen'):
        subprocess.run(['ssh-keygen', '-q', '-t', 'rsa', '-b', '3072', '-N', '', '-C', 'aiw-zpr-lab', '-f', str(KEY)],
                       check=True, stdin=subprocess.DEVNULL)
        return
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    k = rsa.generate_private_key(public_exponent=65537, key_size=3072)
    private_write(KEY, k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.OpenSSH,
                                       serialization.NoEncryption()).decode())
    pub = k.public_key().public_bytes(serialization.Encoding.OpenSSH, serialization.PublicFormat.OpenSSH).decode()
    KEY.with_suffix('.pub').write_text(pub + ' aiw-zpr-lab\n')


def ensure_zpr(cloud, enable):
    try:
        conf = cloud.zpr.get_configuration(compartment_id=cloud.tenancy).data
        if conf.zpr_status == 'ENABLED' and conf.lifecycle_state == 'ACTIVE':
            return
    except oci.exceptions.ServiceError as e:
        if e.status != 404:
            raise
    if not enable:
        sys.exit('Zero Trust Packet Routing is not enabled in this tenancy. It is a tenancy-wide setting.\n'
                 'Enable it in the Console (Identity & Security > Zero Trust Packet Routing), or rerun build with --enable-zpr.')
    say('Enabling Zero Trust Packet Routing for the tenancy')
    cloud.zpr.create_configuration(oci.zpr.models.CreateConfigurationDetails(compartment_id=cloud.tenancy, zpr_status='ENABLED'))
    for _ in range(60):
        try:
            conf = cloud.zpr.get_configuration(compartment_id=cloud.tenancy).data
            if conf.lifecycle_state == 'ACTIVE':
                return
        except oci.exceptions.ServiceError:
            pass
        time.sleep(10)
    sys.exit('ZPR did not become ACTIVE; check Identity & Security > Zero Trust Packet Routing.')


def build(parent, enable, region=None):
    s = load_settings()
    cloud = Cloud(s.get('region') or region, s.get('home_region'))
    ensure_zpr(cloud, enable)
    prepare(cloud, parent)
    say('Terraform init')
    terraform('init', '-input=false', '-no-color', capture=True)
    say('Creating the lab compartment')
    terraform('apply', '-input=false', '-no-color', '-auto-approve', f'-var-file={TFVARS}',
              '-target=oci_identity_compartment.lab', capture=True)
    cid = json.loads(terraform('output', '-json', 'compartment_id', capture=True))
    for _ in range(40):  # a new compartment can take a few minutes to reach a non-home region
        try:
            cloud.vn.list_vcns(cid)
            break
        except oci.exceptions.ServiceError as e:
            if e.status != 404:
                raise
            time.sleep(15)
    say('Creating the ZPR namespace and attributes')
    terraform('apply', '-input=false', '-no-color', '-auto-approve', f'-var-file={TFVARS}',
              '-target=oci_security_attribute_security_attribute.label', capture=True)
    say('Creating the lab resources (Terraform apply, about 5 minutes)')
    # New ZPR attributes take a few minutes to reach the lab region; until then OCI refuses
    # labelled VCNs (400). Terraform resumes where it stopped, so retry a few times.
    for attempt in range(1, 7):
        try:
            terraform('apply', '-input=false', '-no-color', '-auto-approve', f'-var-file={TFVARS}')
            break
        except SystemExit:
            if attempt == 6:
                raise
            say('Waiting 60 seconds for OCI to distribute the new ZPR attributes, then retrying')
            time.sleep(60)
    o = outputs()
    say(f"Load balancer {o['lb_ip']}. Waiting for the database VM to install Oracle Database Free (about 15-20 minutes)")
    for _ in range(90):
        if customer_query(o['lb_ip']):
            say('Customer query works: the application reached the database.')
            break
        time.sleep(20)
    else:
        sys.exit('The application did not reach the database within 30 minutes. Run "python3 lab.py status" again later.')
    return status()


# ---------------------------------------------------------------- checks
def customer_query(ip):
    try:
        with urllib.request.urlopen(f'http://{ip}/dbcheck', timeout=15) as r:
            body = json.loads(r.read())
        return body.get('status') == 'DB connection successful' and len(body.get('products', [])) == 3
    except Exception:
        return False


def test_vm_check(ip):
    """Run the port test on the Test VM over SSH. Returns REACHABLE, BLOCKED or an error text."""
    if not shutil.which('ssh'):
        return 'NOT RUN', 'ssh is not installed here; run this lab from Cloud Shell'
    for attempt in range(4):  # the Test VM's sshd sometimes drops the first connections ("kex ... closed")
        p = subprocess.run(['ssh', '-i', str(KEY), '-o', 'StrictHostKeyChecking=accept-new', '-o', 'LogLevel=ERROR',
                            '-o', 'ConnectTimeout=20', '-o', f'UserKnownHostsFile={LOCAL / "known_hosts"}',
                            f'opc@{ip}', '/usr/local/bin/check-database'],
                           text=True, capture_output=True, timeout=60)
        out = (p.stdout + p.stderr).strip()
        if 'REACHABLE' in out or 'BLOCKED' in out or attempt == 3:
            break
        time.sleep(15)
    if 'REACHABLE' in out:
        return 'REACHABLE', out
    if 'BLOCKED' in out and ('timeout' in out.lower() or 'Timeout' in out):
        return 'BLOCKED', out
    return 'ERROR', out or f'ssh exit {p.returncode}'


def resources(cloud, o):
    rows = []
    for k, i in o['instance_ids'].items():
        d = cloud.compute.get_instance(i).data
        rows.append(('vm', k, i, d.display_name, d.lifecycle_state, d.security_attributes or {}))
    for k, i in o['vcn_ids'].items():
        d = cloud.vn.get_vcn(i).data
        rows.append(('vcn', k, i, d.display_name, d.lifecycle_state, d.security_attributes or {}))
    d = cloud.lb.get_load_balancer(o['load_balancer_id']).data
    rows.append(('lb', 'lb', d.id, d.display_name, d.lifecycle_state, d.security_attributes or {}))
    return rows


def business_policies(cloud, ns, admin_id):
    """ZPR policies (other than the lab's admin policy) that mention this lab's namespace."""
    found = []
    for p in oci.pagination.list_call_get_all_results(cloud.zpr.list_zpr_policies, compartment_id=cloud.tenancy).data:
        if p.id == admin_id or p.lifecycle_state in ('DELETED', 'DELETING'):
            continue
        full = cloud.zpr.get_zpr_policy(p.id).data
        if any(f'{ns}.' in st for st in full.statements):
            found.append(full)
    return found


def status(quiet=False):
    s = load_settings()
    o = outputs()
    if not o:
        sys.exit('No lab found here; run "python3 lab.py build" first.')
    cloud = Cloud(s['region'], s['home_region'])
    ns = o['namespace']
    rows = resources(cloud, o)
    labelled = [r for r in rows if r[0] != 'vcn' and r[5].get(ns)]
    vcns_ready = all(r[5].get(ns, {}).get('networks', {}).get('value') == r[1] for r in rows if r[0] == 'vcn')
    biz = business_policies(cloud, ns, o['admin_policy_id'])
    port = test_vm_check(o['test_public_ip'])
    if not quiet:
        for kind, key, ocid, name, state, attrs in rows:
            print(f"  {name:22} {state:10} {json.dumps(attrs.get(ns)) if attrs.get(ns) else 'no label'}")
        print(f"  Business policies: {', '.join(p.name for p in biz) or 'none'}")
        print(f"  Customer query (http://{o['lb_ip']}/dbcheck): {'works' if customer_query(o['lb_ip']) else 'FAILS'}")
        print(f"  Test VM -> database port 1521: {port[0]}  ({port[1].splitlines()[-1] if port[1] else ''})")
        if not vcns_ready:
            print('ZPR lab: the VCN labels are missing; run "python3 lab.py reset"')
        elif not labelled and not biz:
            print('ZPR lab: STARTING STATE' + ('' if port[0] == 'REACHABLE' else '  (Test VM check did not run cleanly; see above)'))
        elif len(labelled) == 4 and biz:
            print('ZPR lab: PROTECTED' + (' - the Test VM is blocked, as intended' if port[0] == 'BLOCKED' else ''))
        else:
            print(f'ZPR lab: IN PROGRESS ({len(labelled)} of 4 labels, {len(biz)} business policy)')
    return True


def reset():
    s = load_settings()
    o = outputs()
    cloud = Cloud(s['region'], s['home_region'])
    ns = o['namespace']
    for kind, key, ocid, name, state, attrs in resources(cloud, o):
        if kind == 'vcn':  # prepared labels: keep them, and put them back if someone removed them
            want = {'networks': {'value': key, 'mode': 'enforce'}}
            if attrs.get(ns) != want:
                cloud.vn.update_vcn(ocid, oci.core.models.UpdateVcnDetails(security_attributes=dict(attrs, **{ns: want})))
                say(f'Restored the prepared label on {name}')
            continue
        if not attrs.get(ns):
            continue
        keep = {k: v for k, v in attrs.items() if k != ns}
        if kind == 'vm':
            cloud.compute.update_instance(ocid, oci.core.models.UpdateInstanceDetails(security_attributes=keep))
        else:
            cloud.lb.update_load_balancer(oci.load_balancer.models.UpdateLoadBalancerDetails(security_attributes=keep), ocid)
        say(f'Removed the {ns} label from {name}')
    for p in business_policies(cloud, ns, o['admin_policy_id']):
        cloud.zpr.delete_zpr_policy(p.id)
        say(f'Deleting ZPR policy {p.name}')
    for _ in range(40):
        if not [r for r in resources(cloud, o) if r[0] != 'vcn' and r[5].get(ns)] and not business_policies(cloud, ns, o['admin_policy_id']):
            break
        time.sleep(15)
    time.sleep(30)
    return status()


def teardown():
    s = load_settings()
    if outputs():
        reset()
    try:
        listed = terraform('state', 'list', capture=True).split()
    except SystemExit:
        listed = []
    if 'oci_security_attribute_security_attribute_namespace.lab' in listed:
        # OCI deletes ZPR attributes and namespaces only after they are retired.
        say('Retiring the ZPR attributes, then deleting all lab resources (about 10 minutes)')
        terraform('apply', '-input=false', '-no-color', '-auto-approve', f'-var-file={TFVARS}', '-var', 'retired=true',
                  '-target=oci_security_attribute_security_attribute_namespace.lab',
                  '-target=oci_security_attribute_security_attribute.label')
    if 'oci_identity_compartment.lab' in listed:
        s['compartment_id'] = terraform('output', '-raw', 'compartment_id', capture=True).strip()
        private_write(SETTINGS, json.dumps(s, indent=2))
        # OCI can take 30 minutes or more to delete a compartment. Terraform would wait for that, so the
        # compartment leaves Terraform's state here and is deleted with one API call after everything else.
        terraform('state', 'rm', 'oci_identity_compartment.lab', capture=True)
    if listed:
        terraform('destroy', '-input=false', '-no-color', '-auto-approve', f'-var-file={TFVARS}')
    if s.get('compartment_id'):
        cloud = Cloud(s['region'], s['home_region'])
        try:
            cloud.iam_home.delete_compartment(s['compartment_id'])
        except oci.exceptions.ServiceError as e:
            if e.status not in (404, 409) and 'non active compartment' not in str(e.message):
                raise
        say(f'Deleting compartment {COMPARTMENT} (30 minutes or more)')
    for f in [SETTINGS, TFVARS]:
        f.unlink(missing_ok=True)
    say('Teardown complete.')
    print('OCI finishes deleting the compartment in the background.')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('command', choices=['build', 'status', 'check', 'reset', 'teardown'])
    ap.add_argument('--parent', help='compartment OCID for the lab compartment (default: tenancy root)')
    ap.add_argument('--enable-zpr', action='store_true', help='enable ZPR for the tenancy if needed')
    ap.add_argument('--region', help='region for the lab resources (default: your Cloud Shell region)')
    ap.add_argument('--yes', action='store_true', help='required for teardown')
    a = ap.parse_args()
    if a.command == 'build':
        build(a.parent, a.enable_zpr, a.region)
    elif a.command == 'status':
        status()
    elif a.command == 'check':
        o = outputs() or sys.exit('No lab found here; run build first.')
        print(test_vm_check(o['test_public_ip'])[1])
    elif a.command == 'reset':
        reset()
    else:
        if not a.yes:
            sys.exit('teardown deletes everything this lab created; rerun with --yes')
        teardown()


if __name__ == '__main__':
    main()
