# Self-paced ZPR lab: Summit Retail three-tier path across two VCNs.
# Creates the starting state only. You create the ZPR business policy and assign
# the security attributes yourself in the Console during the lab.
terraform {
  required_version = ">= 1.5.0, < 2.0.0"
  required_providers {
    oci = {
      source  = "oracle/oci"
      version = "= 7.32.0"
    }
  }
  backend "local" {
    path = ".local/terraform.tfstate"
  }
}

# In Cloud Shell the provider uses your Cloud Shell sign-in. No API keys are packaged.
provider "oci" {
  region = var.region
}
provider "oci" {
  alias  = "home"
  region = var.home_region
}

variable "region" { type = string }
variable "home_region" { type = string }
variable "tenancy_id" { type = string }
variable "parent_compartment_id" { type = string }
variable "availability_domain" { type = string }
variable "image_id" { type = string }
variable "shape" { type = string }
variable "ssh_public_key" { type = string }
variable "namespace" {
  type = string
  validation {
    condition     = can(regex("^[a-z][a-z0-9]{3,30}$", var.namespace))
    error_message = "Namespace: lowercase letters and digits, 4-31 characters."
  }
}
variable "admin_cidr" {
  type    = string
  default = "0.0.0.0/0"
  validation {
    condition     = can(cidrhost(var.admin_cidr, 0))
    error_message = "Use an IPv4 CIDR, for example 203.0.113.10/32."
  }
}
variable "database_password" {
  type      = string
  sensitive = true
  validation {
    condition     = can(regex("^[A-Za-z0-9]{24,40}$", var.database_password))
    error_message = "Use a generated 24-40 character alphanumeric password."
  }
}
variable "retired" {
  type    = bool
  default = false
}

locals {
  prefix = "aiw-zpr"
  ns     = var.namespace
  tags   = { "aiw-lab" = "zpr" }
}

# ---------------------------------------------------------------- compartment and network
resource "oci_identity_compartment" "lab" {
  provider       = oci.home
  compartment_id = var.parent_compartment_id
  name           = "aiw-zpr-lab"
  description    = "Self-paced ZPR lab (synthetic data only). Remove with lab.py teardown."
  enable_delete  = true
  freeform_tags  = local.tags
}

resource "oci_core_vcn" "net" {
  for_each       = { frontend = "10.96.0.0/16", backend = "10.97.0.0/16" }
  compartment_id = oci_identity_compartment.lab.id
  display_name   = "${local.prefix}-${each.key}-vcn"
  cidr_blocks    = [each.value]
  dns_label      = each.key
  freeform_tags  = local.tags
  # The networks label is part of the prepared state. ZPR evaluates "in <ns>.networks:... VCN" reliably
  # only for VCNs that carried the label from creation; labels added to an existing VCN later were not
  # honoured in testing (18 Oct 2026), so the learner labels only the load balancer and the three VMs.
  security_attributes = {
    "${local.ns}.networks.value" = each.key
    "${local.ns}.networks.mode"  = "enforce"
  }
  lifecycle { ignore_changes = [defined_tags] }
  depends_on = [oci_security_attribute_security_attribute.label]
}
resource "oci_core_drg" "lab" {
  compartment_id = oci_identity_compartment.lab.id
  display_name   = "${local.prefix}-drg"
  freeform_tags  = local.tags
}
resource "oci_core_drg_attachment" "net" {
  for_each     = oci_core_vcn.net
  drg_id       = oci_core_drg.lab.id
  display_name = "${local.prefix}-${each.key}-attachment"
  network_details {
    id             = each.value.id
    type           = "VCN"
    vcn_route_type = "VCN_CIDRS"
  }
  freeform_tags = local.tags
}
resource "oci_core_internet_gateway" "front" {
  compartment_id = oci_identity_compartment.lab.id
  vcn_id         = oci_core_vcn.net["frontend"].id
  display_name   = "${local.prefix}-igw"
  enabled        = true
  freeform_tags  = local.tags
}
resource "oci_core_nat_gateway" "net" {
  for_each       = oci_core_vcn.net
  compartment_id = oci_identity_compartment.lab.id
  vcn_id         = each.value.id
  display_name   = "${local.prefix}-${each.key}-nat"
  freeform_tags  = local.tags
}
locals {
  subnets = {
    public = { network = "frontend", cidr = "10.96.0.0/24", private = false, peer = "10.97.0.0/16" }
    app    = { network = "frontend", cidr = "10.96.10.0/24", private = true, peer = "10.97.0.0/16" }
    db     = { network = "backend", cidr = "10.97.10.0/24", private = true, peer = "10.96.0.0/16" }
  }
}
resource "oci_core_route_table" "subnet" {
  for_each       = local.subnets
  compartment_id = oci_identity_compartment.lab.id
  vcn_id         = oci_core_vcn.net[each.value.network].id
  display_name   = "${local.prefix}-${each.key}-routes"
  route_rules {
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
    network_entity_id = each.value.private ? oci_core_nat_gateway.net[each.value.network].id : oci_core_internet_gateway.front.id
  }
  route_rules {
    destination       = each.value.peer
    destination_type  = "CIDR_BLOCK"
    network_entity_id = oci_core_drg.lab.id
  }
  freeform_tags = local.tags
  depends_on    = [oci_core_drg_attachment.net]
}
resource "oci_core_security_list" "empty" {
  for_each       = oci_core_vcn.net
  compartment_id = oci_identity_compartment.lab.id
  vcn_id         = each.value.id
  display_name   = "${local.prefix}-${each.key}-empty-sl"
  freeform_tags  = local.tags
}
resource "oci_core_subnet" "lab" {
  for_each                   = local.subnets
  compartment_id             = oci_identity_compartment.lab.id
  vcn_id                     = oci_core_vcn.net[each.value.network].id
  display_name               = "${local.prefix}-${each.key}-subnet"
  cidr_block                 = each.value.cidr
  dns_label                  = each.key
  prohibit_public_ip_on_vnic = each.value.private
  route_table_id             = oci_core_route_table.subnet[each.key].id
  security_list_ids          = [oci_core_security_list.empty[each.value.network].id]
  freeform_tags              = local.tags
}

# ---------------------------------------------------------------- NSGs
resource "oci_core_network_security_group" "role" {
  for_each       = { lb = "frontend", app = "frontend", test = "frontend", db = "backend" }
  compartment_id = oci_identity_compartment.lab.id
  vcn_id         = oci_core_vcn.net[each.value].id
  display_name   = "${local.prefix}-${each.key}-nsg"
  freeform_tags  = local.tags
}
locals {
  inbound = {
    customer = { role = "lb", source = "0.0.0.0/0", port = 80 }
    admin    = { role = "test", source = var.admin_cidr, port = 22 }
    app_ssh  = { role = "app", source = "10.96.0.10/32", port = 22 }
    db_ssh   = { role = "db", source = "10.96.0.10/32", port = 22 }
    # Deliberately broad: the network allows both the app and the Test VM, so the lab isolates what ZPR adds.
    db_demo = { role = "db", source = "10.96.0.0/16", port = 1521 }
  }
}
resource "oci_core_network_security_group_security_rule" "inbound" {
  for_each                  = local.inbound
  network_security_group_id = oci_core_network_security_group.role[each.value.role].id
  direction                 = "INGRESS"
  protocol                  = "6"
  source                    = each.value.source
  source_type               = "CIDR_BLOCK"
  tcp_options {
    destination_port_range {
      min = each.value.port
      max = each.value.port
    }
  }
  description = each.key == "db_demo" ? "Lab: front-end VCN to database port (deliberately broad)" : "Lab ${each.key}"
}
resource "oci_core_network_security_group_security_rule" "app_http" {
  network_security_group_id = oci_core_network_security_group.role["app"].id
  direction                 = "INGRESS"
  protocol                  = "6"
  source                    = oci_core_network_security_group.role["lb"].id
  source_type               = "NETWORK_SECURITY_GROUP"
  tcp_options {
    destination_port_range {
      min = 80
      max = 80
    }
  }
}
resource "oci_core_network_security_group_security_rule" "egress" {
  for_each                  = oci_core_network_security_group.role
  network_security_group_id = each.value.id
  direction                 = "EGRESS"
  protocol                  = "all"
  destination               = "0.0.0.0/0"
  destination_type          = "CIDR_BLOCK"
}

# ---------------------------------------------------------------- VMs and load balancer
locals {
  machines = {
    app  = { subnet = "app", ip = "10.96.10.20", memory = 4 }
    db   = { subnet = "db", ip = "10.97.10.20", memory = 8 }
    test = { subnet = "public", ip = "10.96.0.10", memory = 4 }
  }
  cloud_init = {
    db = {
      write_files = [
        { path = "/root/summit-zpr/password", permissions = "0600", content = var.database_password },
        { path = "/usr/local/sbin/summit-zpr-bootstrap", permissions = "0700", content = file("${path.module}/bootstrap-db.sh") }
      ]
      runcmd = [["/usr/local/sbin/summit-zpr-bootstrap"]]
    }
    app = {
      write_files = [
        { path = "/etc/summit-zpr.env", permissions = "0600", content = "DB_HOST=10.97.10.20\nDB_PASSWORD=${var.database_password}\n" },
        { path = "/opt/summit-zpr/app.py", permissions = "0644", content = file("${path.module}/app.py") },
        { path = "/usr/local/sbin/summit-zpr-bootstrap", permissions = "0700", content = file("${path.module}/bootstrap-app.sh") }
      ]
      runcmd = [["/usr/local/sbin/summit-zpr-bootstrap"]]
    }
    test = {
      write_files = [
        { path = "/usr/local/bin/check-database", permissions = "0755", content = "#!/usr/bin/python3\nimport socket\ntry:\n    with socket.create_connection(('10.97.10.20', 1521), timeout=5):\n        print('DATABASE PORT REACHABLE')\nexcept OSError as e:\n    print('DATABASE PORT BLOCKED:', type(e).__name__)\n    raise SystemExit(2)\n" }
      ]
      runcmd = [["sh", "-c", "echo Summit ZPR test host ready"]]
    }
  }
}
resource "oci_core_instance" "vm" {
  for_each            = local.machines
  compartment_id      = oci_identity_compartment.lab.id
  availability_domain = var.availability_domain
  display_name        = "${local.prefix}-${each.key}"
  shape               = var.shape
  shape_config {
    ocpus         = 1
    memory_in_gbs = each.value.memory
  }
  source_details {
    source_type             = "image"
    source_id               = var.image_id
    boot_volume_size_in_gbs = 50
  }
  create_vnic_details {
    subnet_id        = oci_core_subnet.lab[each.value.subnet].id
    assign_public_ip = each.key == "test"
    private_ip       = each.value.ip
    hostname_label   = "zpr-${each.key}"
    nsg_ids          = [oci_core_network_security_group.role[each.key].id]
    freeform_tags    = local.tags
  }
  metadata = {
    ssh_authorized_keys = var.ssh_public_key
    user_data           = base64encode("#cloud-config\n${yamlencode(local.cloud_init[each.key])}")
  }
  preserve_boot_volume = false
  freeform_tags        = local.tags
  lifecycle { ignore_changes = [security_attributes, defined_tags, metadata] }
  depends_on = [oci_core_network_security_group_security_rule.inbound, oci_core_network_security_group_security_rule.egress]
}
resource "oci_load_balancer_load_balancer" "lab" {
  compartment_id               = oci_identity_compartment.lab.id
  display_name                 = "${local.prefix}-lb"
  shape                        = "flexible"
  is_private                   = false
  is_delete_protection_enabled = false
  subnet_ids                   = [oci_core_subnet.lab["public"].id]
  network_security_group_ids   = [oci_core_network_security_group.role["lb"].id]
  shape_details {
    minimum_bandwidth_in_mbps = 10
    maximum_bandwidth_in_mbps = 10
  }
  freeform_tags = local.tags
  lifecycle { ignore_changes = [security_attributes, defined_tags] }
}
resource "oci_load_balancer_backend_set" "app" {
  load_balancer_id = oci_load_balancer_load_balancer.lab.id
  name             = "summit-app"
  policy           = "ROUND_ROBIN"
  health_checker {
    protocol          = "HTTP"
    port              = 80
    url_path          = "/healthz"
    return_code       = 200
    interval_ms       = 10000
    timeout_in_millis = 3000
    retries           = 3
  }
}
resource "oci_load_balancer_backend" "app" {
  load_balancer_id = oci_load_balancer_load_balancer.lab.id
  backendset_name  = oci_load_balancer_backend_set.app.name
  ip_address       = oci_core_instance.vm["app"].private_ip
  port             = 80
}
resource "oci_load_balancer_listener" "http" {
  load_balancer_id         = oci_load_balancer_load_balancer.lab.id
  name                     = "http"
  default_backend_set_name = oci_load_balancer_backend_set.app.name
  port                     = 80
  protocol                 = "HTTP"
}

# ---------------------------------------------------------------- ZPR preparation (home region)
# The namespace and attribute definitions are prepared; you assign them to resources in the lab.
resource "oci_security_attribute_security_attribute_namespace" "lab" {
  provider       = oci.home
  compartment_id = oci_identity_compartment.lab.id
  name           = local.ns
  is_retired     = var.retired
  description    = "Self-paced ZPR lab attributes"
  freeform_tags  = local.tags
}
resource "oci_security_attribute_security_attribute" "label" {
  provider = oci.home
  for_each = {
    networks = ["frontend", "backend"]
    role     = ["loadbalancer", "application", "database", "test"]
  }
  security_attribute_namespace_id = oci_security_attribute_security_attribute_namespace.lab.id
  name                            = each.key
  is_retired                      = var.retired
  description                     = "ZPR lab ${each.key}"
  validator {
    validator_type = "ENUM"
    values         = each.value
  }
}
# Administration paths that must keep working once labels are enforced:
# SSH to the Test VM, SSH from the Test VM to the app and database, and outbound package downloads.
# Deliberately no Test VM -> database port 1521 statement.
resource "oci_zpr_zpr_policy" "admin" {
  provider       = oci.home
  compartment_id = var.tenancy_id
  name           = "${local.prefix}-${local.ns}-administration"
  description    = "Self-paced ZPR lab: administration paths only"
  statements = concat([
    "in ${local.ns}.networks:frontend VCN allow '${var.admin_cidr}' to connect to ${local.ns}.role:test endpoints with protocol='tcp/22'",
    "in ${local.ns}.networks:frontend VCN allow ${local.ns}.role:test endpoints to connect to ${local.ns}.role:application endpoints with protocol='tcp/22'",
    "allow ${local.ns}.role:test endpoints in ${local.ns}.networks:frontend VCN to connect to ${local.ns}.role:database endpoints with protocol='tcp/22' in ${local.ns}.networks:backend VCN"
    ], flatten([for r, n in { application = "frontend", database = "backend", test = "frontend" } : [
      for port in [80, 443] : "in ${local.ns}.networks:${n} VCN allow ${local.ns}.role:${r} endpoints to connect to '0.0.0.0/0' with protocol='tcp/${port}'"
  ]]))
  freeform_tags = local.tags
  depends_on    = [oci_security_attribute_security_attribute.label]
}

output "compartment_id" {
  value = oci_identity_compartment.lab.id
}

output "lab" {
  # null until the whole lab exists (the build first creates only the compartment)
  value = try({
    compartment_id   = oci_identity_compartment.lab.id
    test_public_ip   = oci_core_instance.vm["test"].public_ip
    lb_ip            = [for d in oci_load_balancer_load_balancer.lab.ip_address_details : d.ip_address if d.is_public][0]
    load_balancer_id = oci_load_balancer_load_balancer.lab.id
    instance_ids     = { for k, v in oci_core_instance.vm : k => v.id }
    vcn_ids          = { for k, v in oci_core_vcn.net : k => v.id }
    db_nsg_id        = oci_core_network_security_group.role["db"].id
    namespace        = local.ns
    admin_policy_id  = oci_zpr_zpr_policy.admin.id
  }, null)
}
