#!/bin/bash
set -euo pipefail
umask 077
exec > /var/log/summit-zpr-bootstrap.log 2>&1
dnf -y install oracle-ai-database-preinstall-26ai curl
install -d -m 700 /root/summit-zpr
curl --fail --location --retry 4 --connect-timeout 30 --max-time 900 \
  https://download.oracle.com/otn-pub/otn_software/db-free/oracle-ai-database-free-26ai-23.26.3-1.el9.x86_64.rpm \
  -o /root/summit-zpr/database.rpm
printf '%s\n' '895fc9df794685b515c4ac83f104dbdfb657eb0e92c41e45c58302fb8fd53e44  /root/summit-zpr/database.rpm' | sha256sum -c -
dnf -y install /root/summit-zpr/database.rpm
DB_PASS=$(cat /root/summit-zpr/password)
printf '%s\n%s\n' "$DB_PASS" "$DB_PASS" | /etc/init.d/oracle-free-26ai configure
systemctl enable oracle-free-26ai
runuser -u oracle -- env ORACLE_SID=FREE ORACLE_HOME=/opt/oracle/product/26ai/dbhomeFree \
  /opt/oracle/product/26ai/dbhomeFree/bin/sqlplus -s '/ as sysdba' <<SQL
whenever sqlerror exit failure
set echo off verify off feedback off
alter pluggable database FREEPDB1 save state;
alter session set container=FREEPDB1;
create user SUMMIT_DATA no authentication default tablespace USERS quota 10M on USERS;
create table SUMMIT_DATA.products (product_name varchar2(80), stock number);
insert into SUMMIT_DATA.products values ('Summit Phone', 24);
insert into SUMMIT_DATA.products values ('Travel Headphones', 18);
insert into SUMMIT_DATA.products values ('Everyday Backpack', 32);
commit;
create user SUMMIT_APP identified by "$DB_PASS";
grant create session to SUMMIT_APP;
grant select on SUMMIT_DATA.products to SUMMIT_APP;
select count(*) as synthetic_product_count from SUMMIT_DATA.products;
exit
SQL
unset DB_PASS
if systemctl is-active --quiet firewalld; then
  firewall-cmd --permanent --add-rich-rule='rule family="ipv4" source address="10.96.0.0/16" port port="1521" protocol="tcp" accept'
  firewall-cmd --reload
fi
rm -f /root/summit-zpr/database.rpm
touch /var/lib/summit-zpr-db-ready
echo 'Summit ZPR database ready'
