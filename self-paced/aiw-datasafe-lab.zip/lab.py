#!/usr/bin/env python3
"""Self-paced Data Safe lab: build the starting state in YOUR OWN tenancy.

Run in OCI Cloud Shell (uses your Cloud Shell sign-in; no API key needed):

    python3 lab.py build                  # about 10 minutes: compartment, database, Data Safe target, synthetic data
    python3 lab.py passwords              # show the ADMIN and SUMMIT_TESTER passwords for Database Actions
    python3 lab.py ready                  # read-only check of the starting state
    python3 lab.py reset                  # after the lab: remove your Data Safe artifacts, restore the unmasked copy
    python3 lab.py teardown --yes         # delete the target, database and compartment

Options for build:
    --parent <compartment-OCID>   create the lab compartment here (default: tenancy root)
    --paid                        use a 2-ECPU paid database instead of an Always Free one

Everything is created in one new compartment, aiw-datasafe-lab, tagged aiw-lab=datasafe.
All records are synthetic. Passwords are generated here and stored only in ~/.aiw/datasafe (mode 0600).
"""
import argparse
import base64
import json
import os
import re
import secrets
import string
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

import oci
import requests

STATE_DIR = Path(os.environ.get('AIW_STATE_DIR', Path.home() / '.aiw' / 'datasafe'))
CHILD_NAME = 'aiw-datasafe-lab'
DB_NAME = 'AIWDSLAB'
DB_DISPLAY = 'aiw-datasafe-db'
TARGET_NAME = 'aiw-datasafe-target'
TAGS = {'aiw-lab': 'datasafe'}
TAG_KEY, TAG_VALUE = 'aiw-lab', 'datasafe'


def oci_auth(region=None):
    """Cloud Shell delegation token by default; AIW_OCI_CONFIG/AIW_OCI_PROFILE select an API-key profile instead."""
    if os.environ.get('AIW_OCI_CONFIG'):
        cfg = oci.config.from_file(os.environ['AIW_OCI_CONFIG'], os.environ.get('AIW_OCI_PROFILE', 'DEFAULT'))
        if region:
            cfg['region'] = region
        return cfg, {}
    if not os.environ.get('OCI_CLI_CONFIG_FILE'):
        sys.exit('Run this in OCI Cloud Shell (or set AIW_OCI_CONFIG to an API-key config file).')
    cfg = oci.config.from_file(os.environ['OCI_CLI_CONFIG_FILE'], os.environ.get('OCI_CLI_PROFILE', 'DEFAULT'))
    token = Path(cfg['delegation_token_file']).read_text().strip()
    cfg['region'] = region or os.environ.get('OCI_REGION') or cfg.get('region')
    return cfg, {'signer': oci.auth.signers.InstancePrincipalsDelegationTokenSigner(delegation_token=token)}

CUSTOMERS = [(i, f, l, f'{f.lower()}.{l.lower()}@example.com', f'202-555-{100 + i:04d}', c)
             for i, (f, l, c) in enumerate([
                 ('Asha', 'Rao', 'Seattle'), ('Maya', 'Shah', 'Austin'), ('Ravi', 'Patel', 'Boston'),
                 ('Nina', 'Mehta', 'Denver'), ('Omar', 'Khan', 'Chicago'), ('Lena', 'Roy', 'Portland'),
                 ('Arun', 'Das', 'Phoenix'), ('Sara', 'Ali', 'Miami'), ('Isha', 'Sen', 'Dallas'),
                 ('Noah', 'Reed', 'Atlanta'), ('Emma', 'Cole', 'Orlando'), ('Liam', 'Park', 'San Diego')], 1)]
ORDERS = [(1000 + i, (i - 1) % 12 + 1, ['Backpack', 'Phone', 'Headphones'][(i - 1) % 3], (i % 3) + 1, 25 * (i % 4 + 1))
          for i in range(1, 19)]
EXPECTED_GRANTS = {('SUMMIT_SOURCE', 'CUSTOMERS', 'SELECT'), ('SUMMIT_TEST', 'CUSTOMERS', 'SELECT'), ('SUMMIT_TEST', 'ORDERS', 'SELECT')}


# ---------------------------------------------------------------- state
def now():
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def load(name, default=None):
    p = STATE_DIR / name
    return json.loads(p.read_text()) if p.exists() else default


def save(name, value):
    STATE_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(STATE_DIR, 0o700)
    tmp = STATE_DIR / (name + '.tmp')
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'w') as f:
        json.dump(value, f, indent=2)
    tmp.replace(STATE_DIR / name)


def say(msg):
    print(f'[{now()}] {msg}', flush=True)


def credentials():
    creds = load('credentials.json')
    if creds is None:
        alphabet = string.ascii_letters + string.digits
        creds = {k: 'Aa9_' + ''.join(secrets.choice(alphabet) for _ in range(24))
                 for k in ('admin', 'source', 'test', 'tester', 'ops')}
        save('credentials.json', creds)
    return creds


# ---------------------------------------------------------------- OCI
class Cloud:
    def __init__(self, parent=None):
        settings = load('settings.json', {})
        cfg, kw = oci_auth(settings.get('region'))
        self.cfg = cfg
        self.iam = oci.identity.IdentityClient(cfg, **kw)
        self.db = oci.database.DatabaseClient(cfg, **kw)
        self.ds = oci.data_safe.DataSafeClient(cfg, **kw)
        self.parent_id = parent or settings.get('parent_id') or cfg['tenancy']
        parent_obj = self.iam.get_compartment(self.parent_id).data if self.parent_id != cfg['tenancy'] else None
        if parent_obj and parent_obj.lifecycle_state != 'ACTIVE':
            sys.exit('The parent compartment is not ACTIVE.')
        if settings.get('parent_id') and parent and parent != settings['parent_id']:
            sys.exit('This lab was already built under another parent; run teardown first.')
        save('settings.json', dict(settings, parent_id=self.parent_id, region=cfg['region']))

    def child(self):
        kids = oci.pagination.list_call_get_all_results(self.iam.list_compartments, self.parent_id).data
        live = [k for k in kids if k.name == CHILD_NAME and k.lifecycle_state == 'ACTIVE']
        if live and live[0].freeform_tags.get(TAG_KEY) != TAG_VALUE:
            sys.exit(f'A compartment named {CHILD_NAME} exists that this lab did not create; rename it or choose another --parent.')
        return live[0] if live else None

    def database(self, cid):
        for attempt in range(12):  # a new compartment takes a minute or two to reach the database service
            try:
                found = oci.pagination.list_call_get_all_results(
                    self.db.list_autonomous_databases, compartment_id=cid, display_name=DB_DISPLAY).data
                break
            except oci.exceptions.ServiceError as e:
                if e.status != 404 or attempt == 11:
                    raise
                time.sleep(15)
        dbs = [d for d in found if d.lifecycle_state not in ('TERMINATED', 'TERMINATING')]
        if len(dbs) > 1:
            sys.exit('More than one matching database; reconcile in Console first.')
        if dbs and dbs[0].freeform_tags.get(TAG_KEY) != TAG_VALUE:
            sys.exit('Database scope guard failed (lab tag missing).')
        return dbs[0] if dbs else None

    def target(self, cid):
        ts = [t for t in oci.pagination.list_call_get_all_results(
            self.ds.list_target_databases, compartment_id=cid, display_name=TARGET_NAME).data
            if t.lifecycle_state not in ('DELETED', 'DELETING')]
        return ts[0] if ts else None


def wait_for(fetch, ok, label, timeout=1800, every=20):
    end = time.time() + timeout
    while True:
        obj = fetch()
        state = getattr(obj, 'lifecycle_state', None)
        if ok(obj):
            say(f'{label}: {state}')
            return obj
        if state in ('FAILED', 'TERMINATED', 'DELETED', 'NEEDS_ATTENTION'):
            sys.exit(f'{label} ended in {state}: {getattr(obj, "lifecycle_details", "")}')
        if time.time() > end:
            sys.exit(f'Timed out waiting for {label} (last state {state}).')
        time.sleep(every)


# ---------------------------------------------------------------- SQL over HTTPS (ORDS REST-enabled SQL)
class Sql:
    def __init__(self, database):
        url = database.connection_urls.sql_dev_web_url  # https://<host>/ords/sql-developer
        self.base = url.split('/ords/')[0] + '/ords'

    def run(self, alias, user, password, statement, binds=None, allow_error=False):
        body = {'statementText': statement}
        if binds:
            body['binds'] = [{'index': i + 1, 'data_type': 'VARCHAR2' if isinstance(v, str) else 'NUMBER', 'value': v}
                             for i, v in enumerate(binds)]
        r = requests.post(f'{self.base}/{alias}/_/sql', json=body, auth=(user, password), timeout=60)
        if r.status_code != 200:
            raise RuntimeError(f'SQL endpoint HTTP {r.status_code} for {user}')
        item = r.json()['items'][0]
        response_text = ' '.join(str(x) for x in item.get('response', []))
        if 'errorCode' in item or 'ORA-' in response_text:
            code = f"ORA-{item['errorCode']:05d}" if isinstance(item.get('errorCode'), int) else response_text[:160]
            if allow_error:
                return {'error': code}
            raise RuntimeError(f'SQL error for {user}: {code} :: {redact(statement)[:80]}')
        rs = item.get('resultSet')
        return rs['items'] if rs else item

    def admin(self, statement, **kw):
        return self.run('admin', 'ADMIN', credentials()['admin'], statement, **kw)

    def ops(self, statement, **kw):
        return self.run('aiw_ops', 'AIW_OPS', credentials()['ops'], statement, **kw)

    def tester(self, statement, **kw):
        return self.run('summit_tester', 'SUMMIT_TESTER', credentials()['tester'], statement, **kw)


def redact(statement):
    """Never echo passwords in error messages."""
    return re.sub(r'(?i)identified by "[^"]*"', 'identified by "***"', statement)


def plsql_block(lines):
    return 'begin\n' + '\n'.join(lines) + '\nend;'


# ---------------------------------------------------------------- build
def build(cloud, paid=False):
    creds = credentials()
    conf = cloud.ds.get_data_safe_configuration().data
    if not conf.is_enabled:
        sys.exit('Oracle Data Safe is not enabled in this region. Open Data Safe in the Console once '
                 '(Oracle Database > Data Safe) and follow the enable prompt, then rerun build.')
    state = load('state.json', {})
    child = cloud.child()
    if not child:
        say(f'Creating compartment {CHILD_NAME}')
        state.setdefault('compartment_token', str(uuid.uuid4()))
        save('state.json', state)
        cloud.iam.create_compartment(oci.identity.models.CreateCompartmentDetails(
            compartment_id=cloud.parent_id, name=CHILD_NAME, freeform_tags=TAGS,
            description='Self-paced Data Safe lab (synthetic data only). Remove with lab.py teardown.'),
            opc_retry_token=state['compartment_token'])
        for _ in range(60):
            child = cloud.child()
            if child:
                break
            time.sleep(5)
        if not child:
            sys.exit('Compartment did not become ACTIVE.')
    say(f'Compartment {child.name}: ACTIVE')
    cid = child.id
    state['compartment_id'] = cid
    save('state.json', state)

    database = cloud.database(cid)
    if not database:
        state.setdefault('db_token', str(uuid.uuid4()))
        save('state.json', state)
        if paid:
            say(f'Creating Autonomous Database {DB_DISPLAY} (paid: 2 ECPU, 20 GB, 19c)')
            details = oci.database.models.CreateAutonomousDatabaseDetails(
                compartment_id=cid, db_name=DB_NAME, display_name=DB_DISPLAY, db_workload='OLTP',
                compute_model='ECPU', compute_count=2, data_storage_size_in_gbs=20, is_free_tier=False,
                license_model='LICENSE_INCLUDED', is_auto_scaling_enabled=False,
                is_auto_scaling_for_storage_enabled=False, is_dedicated=False,
                admin_password=creds['admin'], is_mtls_connection_required=True, db_version='19c',
                freeform_tags=TAGS)
        else:
            say(f'Creating Autonomous Database {DB_DISPLAY} (Always Free)')
            details = oci.database.models.CreateAutonomousDatabaseDetails(
                compartment_id=cid, db_name=DB_NAME, display_name=DB_DISPLAY, db_workload='OLTP',
                is_free_tier=True, admin_password=creds['admin'], is_mtls_connection_required=True,
                freeform_tags=TAGS)
        try:
            cloud.db.create_autonomous_database(details, opc_retry_token=state['db_token'])
        except oci.exceptions.ServiceError as e:
            if not paid and e.status in (400, 409):
                sys.exit(f'Always Free database not available ({e.code}: {e.message[:160]}). '
                         'You may already have two Always Free databases, or this is not your home region. '
                         'Rerun with --paid, or free up an Always Free database.')
            raise
        time.sleep(10)
        database = cloud.database(cid)
    database = wait_for(lambda: cloud.db.get_autonomous_database(database.id).data,
                        lambda d: d.lifecycle_state == 'AVAILABLE', 'Database')
    state['database_id'] = database.id
    save('state.json', state)

    sql = Sql(database)
    seed(sql, state)

    target = cloud.target(cid)
    if not target:
        say(f'Registering Data Safe target {TARGET_NAME}')
        state.setdefault('target_token', str(uuid.uuid4()))
        save('state.json', state)
        target = cloud.ds.create_target_database(oci.data_safe.models.CreateTargetDatabaseDetails(
            compartment_id=cid, display_name=TARGET_NAME, freeform_tags=TAGS,
            description='Incident-05 synthetic discovery and masking demo',
            database_details=oci.data_safe.models.AutonomousDatabaseDetails(
                infrastructure_type='ORACLE_CLOUD', autonomous_database_id=database.id)),
            opc_retry_token=state['target_token']).data
    target = wait_for(lambda: cloud.ds.get_target_database(target.id).data,
                      lambda t: t.lifecycle_state == 'ACTIVE', 'Data Safe target')
    state['target_id'] = target.id
    save('state.json', state)

    # Data Safe service account roles: assessment and discovery are default for ADB; masking is added.
    sql.admin("begin DS_TARGET_UTIL.GRANT_ROLE('DS$DATA_MASKING_ROLE'); end;")
    say('Granted DS$DATA_MASKING_ROLE to the Data Safe service account')
    say('Build complete. Running the starting-state check.')
    return ready(cloud)


def seed(sql, state):
    creds = credentials()
    users = {'SUMMIT_SOURCE': 'source', 'SUMMIT_TEST': 'test', 'SUMMIT_TESTER': 'tester', 'AIW_OPS': 'ops'}
    existing = {r['username'] for r in sql.admin("select username from dba_users where username in ('SUMMIT_SOURCE','SUMMIT_TEST','SUMMIT_TESTER','AIW_OPS')")}
    for user, key in users.items():
        if user not in existing:
            sql.admin(f'create user {user} identified by "{creds[key]}" default tablespace DATA temporary tablespace TEMP quota 20M on DATA')
            sql.admin(f'grant create session to {user}')
            say(f'Created database user {user}')
    sql.admin('grant create table to SUMMIT_SOURCE')
    sql.admin('grant create table to SUMMIT_TEST')
    # Operations account for checks and resets, so the learner can change the ADMIN password freely.
    for priv in ['select any dictionary', 'select any table', 'create any table', 'drop any table',
                 'insert any table', 'update any table', 'alter any table', 'create any index', 'drop any index',
                 'grant any object privilege']:
        sql.admin(f'grant {priv} to AIW_OPS')
    sql.admin('grant select_catalog_role to AIW_OPS')
    # REST-enable the schemas used over HTTPS (ops for checks; tester so the learner can sign in to Database Actions).
    for schema, alias in [('AIW_OPS', 'aiw_ops'), ('SUMMIT_TESTER', 'summit_tester')]:
        sql.admin(plsql_block([f"ORDS_ADMIN.ENABLE_SCHEMA(p_enabled => TRUE, p_schema => '{schema}', "
                               f"p_url_mapping_type => 'BASE_PATH', p_url_mapping_pattern => '{alias}', p_auto_rest_auth => TRUE);"]))

    if not state.get('seed_complete'):
        have = sql.admin("select count(*) n from dba_tables where owner='SUMMIT_SOURCE' and table_name in ('CUSTOMERS','ORDERS')")[0]['n']
        if have:
            sys.exit('Source tables exist but seed is not recorded as complete; reconcile before reseeding.')
        sql.admin('create table SUMMIT_SOURCE.CUSTOMERS (CUSTOMER_ID number primary key, FIRST_NAME varchar2(80), '
                  'LAST_NAME varchar2(80), EMAIL varchar2(160), PHONE_NUMBER varchar2(40), CITY varchar2(80))')
        sql.admin('create table SUMMIT_SOURCE.ORDERS (ORDER_ID number primary key, CUSTOMER_ID number references '
                  'SUMMIT_SOURCE.CUSTOMERS(CUSTOMER_ID), PRODUCT varchar2(80), QUANTITY number, UNIT_PRICE number(10,2))')
        rows = [f"insert into SUMMIT_SOURCE.CUSTOMERS values ({c[0]},'{c[1]}','{c[2]}','{c[3]}','{c[4]}','{c[5]}');" for c in CUSTOMERS]
        rows += [f"insert into SUMMIT_SOURCE.ORDERS values ({o[0]},{o[1]},'{o[2]}',{o[3]},{o[4]});" for o in ORDERS]
        sql.admin(plsql_block(rows + ['commit;']))
        state['seed_complete'] = True
        state['seeded_at'] = now()
        save('state.json', state)
        say('Seeded SUMMIT_SOURCE: 12 customers, 18 orders (synthetic)')
    restore_test_copy(sql.admin)


def restore_test_copy(run):
    """Recreate SUMMIT_TEST as an unmasked copy of SUMMIT_SOURCE and restore the tester's three grants."""
    for t in ('ORDERS', 'CUSTOMERS'):
        run(f'drop table SUMMIT_TEST.{t} purge', allow_error=True)
    run('create table SUMMIT_TEST.CUSTOMERS as select * from SUMMIT_SOURCE.CUSTOMERS')
    run('alter table SUMMIT_TEST.CUSTOMERS add constraint SUMMIT_TEST_CUSTOMER_PK primary key(CUSTOMER_ID)')
    run('create table SUMMIT_TEST.ORDERS as select * from SUMMIT_SOURCE.ORDERS')
    run('alter table SUMMIT_TEST.ORDERS add constraint SUMMIT_TEST_ORDER_PK primary key(ORDER_ID)')
    run('alter table SUMMIT_TEST.ORDERS add constraint SUMMIT_TEST_ORDER_CUSTOMER_FK foreign key(CUSTOMER_ID) '
        'references SUMMIT_TEST.CUSTOMERS(CUSTOMER_ID)')
    run('grant select on SUMMIT_TEST.CUSTOMERS to SUMMIT_TESTER')
    run('grant select on SUMMIT_TEST.ORDERS to SUMMIT_TESTER')
    run('grant select on SUMMIT_SOURCE.CUSTOMERS to SUMMIT_TESTER')
    say('SUMMIT_TEST restored as an unmasked copy; tester grants restored (including the deliberate source grant)')


# ---------------------------------------------------------------- checks
def ready(cloud, quiet=False):
    state = load('state.json', {})
    child = cloud.child()
    checks = {}
    if not child:
        print(json.dumps({'ready': False, 'reason': 'compartment missing'}))
        return False
    cid = child.id
    database = cloud.database(cid)
    target = cloud.target(cid)
    checks['database_available'] = bool(database) and database.lifecycle_state == 'AVAILABLE'
    checks['target_active'] = bool(target) and target.lifecycle_state == 'ACTIVE'
    if checks['database_available']:
        sql = Sql(database)
        ops = sql.ops
        src_c = ops('select CUSTOMER_ID,FIRST_NAME,LAST_NAME,EMAIL,PHONE_NUMBER,CITY from SUMMIT_SOURCE.CUSTOMERS order by 1')
        tst_c = ops('select CUSTOMER_ID,FIRST_NAME,LAST_NAME,EMAIL,PHONE_NUMBER,CITY from SUMMIT_TEST.CUSTOMERS order by 1')
        src_o = ops('select ORDER_ID,CUSTOMER_ID,PRODUCT,QUANTITY,UNIT_PRICE from SUMMIT_SOURCE.ORDERS order by 1')
        tst_o = ops('select ORDER_ID,CUSTOMER_ID,PRODUCT,QUANTITY,UNIT_PRICE from SUMMIT_TEST.ORDERS order by 1')
        as_tuples = lambda rows, keys: [tuple(r[k] for k in keys) for r in rows]
        ck = ['customer_id', 'first_name', 'last_name', 'email', 'phone_number', 'city']
        ok_ = ['order_id', 'customer_id', 'product', 'quantity', 'unit_price']
        checks['source_matches_seed'] = as_tuples(src_c, ck) == [tuple(c) for c in CUSTOMERS] and as_tuples(src_o, ok_) == [tuple(o) for o in ORDERS]
        checks['test_copy_unmasked'] = src_c == tst_c and src_o == tst_o
        join = ops('select count(*) n, sum(o.QUANTITY*o.UNIT_PRICE) total from SUMMIT_TEST.ORDERS o join SUMMIT_TEST.CUSTOMERS c on o.CUSTOMER_ID=c.CUSTOMER_ID')[0]
        checks['test_join_18_orders_2200'] = (join['n'], join['total']) == (18, 2200)
        cons = ops("select constraint_type t, status s, validated v from dba_constraints where owner='SUMMIT_TEST' and constraint_type in ('P','R')")
        checks['test_constraints_valid'] = sorted((c['t'], c['s'], c['v']) for c in cons) == [('P', 'ENABLED', 'VALIDATED')] * 2 + [('R', 'ENABLED', 'VALIDATED')]
        grants = {(g['owner'], g['table_name'], g['privilege']) for g in ops("select owner, table_name, privilege from dba_tab_privs where grantee='SUMMIT_TESTER'")}
        checks['tester_grants_exact'] = grants == EXPECTED_GRANTS
        # The learner may change the ADMIN and SUMMIT_TESTER passwords, so check the account, not a sign-in.
        acct = ops("select account_status s from dba_users where username='SUMMIT_TESTER'")
        checks['tester_account_open'] = bool(acct) and acct[0]['s'] == 'OPEN'
        checks['tester_still_has_source_grant'] = ('SUMMIT_SOURCE', 'CUSTOMERS', 'SELECT') in grants
        roles = {r['granted_role'] for r in ops("select granted_role from dba_role_privs where grantee='DS$ADMIN'")}
        checks['data_safe_roles'] = {'DS$ASSESSMENT_ROLE', 'DS$DATA_DISCOVERY_ROLE', 'DS$DATA_MASKING_ROLE'} <= roles
    ds = cloud.ds
    models = [m for m in oci.pagination.list_call_get_all_results(ds.list_sensitive_data_models, cid).data if m.lifecycle_state != 'DELETED']
    policies = [p for p in oci.pagination.list_call_get_all_results(ds.list_masking_policies, cid).data if p.lifecycle_state != 'DELETED']
    reports = oci.pagination.list_call_get_all_results(ds.list_masking_reports, cid).data
    checks['no_sensitive_data_model'] = len(models) == 0
    checks['no_masking_policy'] = len(policies) == 0
    checks['no_masking_report'] = len(reports) == 0
    passed = all(checks.values())
    result = {'at': now(), 'ready': passed, 'checks': checks}
    save('ready-last.json', result)
    if not quiet:
        for k, v in checks.items():
            print(f"  {'OK  ' if v else 'FAIL'} {k}")
        print('Data Safe lab: READY' if passed else 'Data Safe lab: NOT READY (run reset)')
    return passed


# ---------------------------------------------------------------- reset and teardown
def reset(cloud):
    child = cloud.child()
    if not child:
        sys.exit('Compartment missing; run build.')
    cid = child.id
    ds = cloud.ds
    # Remove artifacts the learner created in Console (masking reports, policies, models, pre-masking reports).
    for p in oci.pagination.list_call_get_all_results(ds.list_masking_policies, cid).data:
        if p.lifecycle_state != 'DELETED':
            ds.delete_masking_policy(p.id)
            say(f'Deleting masking policy {p.display_name}')
    for r in oci.pagination.list_call_get_all_results(ds.list_masking_reports, cid).data:
        try:
            ds.delete_masking_report(r.id)
            say('Deleting masking report')
        except oci.exceptions.ServiceError as e:
            say(f'Masking report not deleted ({e.status}); it may clear with its policy')
    for m in oci.pagination.list_call_get_all_results(ds.list_sensitive_data_models, cid).data:
        if m.lifecycle_state != 'DELETED':
            ds.delete_sensitive_data_model(m.id)
            say(f'Deleting sensitive data model {m.display_name}')
    database = cloud.database(cid)
    sql = Sql(database)
    restore_test_copy(sql.ops)
    for _ in range(30):
        left = ([p for p in oci.pagination.list_call_get_all_results(ds.list_masking_policies, cid).data if p.lifecycle_state != 'DELETED']
                + [m for m in oci.pagination.list_call_get_all_results(ds.list_sensitive_data_models, cid).data if m.lifecycle_state != 'DELETED'])
        if not left:
            break
        time.sleep(10)
    return ready(cloud)


def teardown(cloud):
    child = cloud.child()
    if not child:
        say('Nothing to remove.')
        return
    cid = child.id
    target = cloud.target(cid)
    if target:
        reset_artifacts_only = [m for m in oci.pagination.list_call_get_all_results(cloud.ds.list_sensitive_data_models, cid).data if m.lifecycle_state != 'DELETED']
        for m in reset_artifacts_only:
            cloud.ds.delete_sensitive_data_model(m.id)
        for p in oci.pagination.list_call_get_all_results(cloud.ds.list_masking_policies, cid).data:
            if p.lifecycle_state != 'DELETED':
                cloud.ds.delete_masking_policy(p.id)
        cloud.ds.delete_target_database(target.id)
        say('Deleting Data Safe target')
        wait_for(lambda: cloud.ds.get_target_database(target.id).data, lambda t: t.lifecycle_state == 'DELETED',
                 'Data Safe target', timeout=1800)
    database = cloud.database(cid)
    if database:
        cloud.db.delete_autonomous_database(database.id)
        say('Terminating database')
        wait_for(lambda: cloud.db.get_autonomous_database(database.id).data, lambda d: d.lifecycle_state == 'TERMINATED',
                 'Database', timeout=1800)
    # Data Safe leaves assessments and audit records behind; remove what can be removed so the compartment can go.
    for lister, deleter in [('list_user_assessments', 'delete_user_assessment'),
                            ('list_security_assessments', 'delete_security_assessment'),
                            ('list_audit_trails', 'delete_audit_trail')]:
        for item in oci.pagination.list_call_get_all_results(getattr(cloud.ds, lister), cid).data:
            try:
                getattr(cloud.ds, deleter)(item.id)
            except oci.exceptions.ServiceError:
                pass  # service-managed records clear on their own
    time.sleep(30)
    try:
        cloud.iam.delete_compartment(cid)
        say('Compartment deletion submitted (OCI finishes it in the background; Data Safe audit records can delay it).')
    except oci.exceptions.ServiceError as e:
        say(f'Compartment not deleted yet ({e.code}). Run teardown again in an hour; Data Safe clears its audit records first.')
    state = load('state.json', {})
    for k in ['compartment_id', 'database_id', 'target_id', 'seed_complete', 'compartment_token', 'db_token', 'target_token']:
        state.pop(k, None)
    save('state.json', state)
    (STATE_DIR / 'credentials.json').unlink(missing_ok=True)
    (STATE_DIR / 'settings.json').unlink(missing_ok=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('command', choices=['build', 'passwords', 'ready', 'reset', 'teardown'])
    ap.add_argument('--yes', action='store_true', help='required for teardown')
    ap.add_argument('--parent', help='compartment OCID for the lab compartment (default: tenancy root)')
    ap.add_argument('--paid', action='store_true', help='use a paid 2-ECPU database instead of Always Free')
    a = ap.parse_args()
    if a.command == 'passwords':
        creds = load('credentials.json')
        if not creds:
            sys.exit('No passwords yet; run build first.')
        print('Database Actions sign-in (keep these private):')
        print(f"  ADMIN          {creds['admin']}")
        print(f"  SUMMIT_TESTER  {creds['tester']}")
        sys.exit(0)
    cloud = Cloud(a.parent if a.command == 'build' else None)
    if a.command == 'build':
        ok = build(cloud, paid=a.paid)
    elif a.command == 'ready':
        ok = ready(cloud)
    elif a.command == 'reset':
        ok = reset(cloud)
    else:
        if not a.yes:
            sys.exit('teardown deletes the lab database, target and compartment; rerun with --yes')
        teardown(cloud)
        ok = True
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
