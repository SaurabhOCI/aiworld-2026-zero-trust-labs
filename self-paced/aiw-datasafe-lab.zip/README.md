# Self-paced lab: mask customer data with Oracle Data Safe

Run in OCI Cloud Shell, in your home region:

    python3 lab.py build        # about 10 minutes
    python3 lab.py passwords    # Database Actions sign-in
    python3 lab.py ready        # check the starting state
    python3 lab.py reset        # start the lab again
    python3 lab.py teardown --yes

Follow the activity guide OUT1015_SelfPaced_DataSafe_Activity_Guide. All data is synthetic.
