#!/usr/bin/env python3
"""Self-paced MCP lab: prepare the identity-domain side in YOUR OWN tenancy (run in OCI Cloud Shell).

    python3 setup.py build [--domain Default] [--user <username>]
    python3 setup.py status          # shows which order roles the lab user holds
    python3 setup.py reset           # remove the Canceller grant again (back to Viewer only)
    python3 setup.py teardown --yes  # delete everything this script created

build creates, in the identity domain you choose:
  integrated app "Summit Orders MCP Resource (lab)": the order service, with scope /orders.invoke
  integrated app "Summit Orders MCP Client (lab)":   the browser client on your laptop (http://127.0.0.1:8891)
  app roles OrderViewer and OrderCanceller, owned by the resource app
  grants: the lab user gets OrderViewer and access to the client app (not OrderCanceller)
  custom claim summit_lab_role_ids, added to access tokens for this scope only
It writes mcp-lab-config.json: download it to your laptop (Cloud Shell menu > Download).
That file holds the client secret; keep it private and delete it when you finish.
"""
import argparse
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import oci

HERE = Path(__file__).resolve().parent
STATE = Path(os.environ.get('AIW_STATE_DIR', Path.home() / '.aiw' / 'mcp'))
CONFIG_OUT = HERE / 'mcp-lab-config.json'
RESOURCE_URI = 'http://127.0.0.1:8892/orders-mcp'
SCOPE = RESOURCE_URI + '/orders.invoke'
REDIRECT = 'http://127.0.0.1:8891/auth/orders/callback'
CLAIM = 'summit_lab_role_ids'
APP_NAMES = ['Summit Orders MCP Resource (lab)', 'Summit Orders MCP Client (lab)']
ROLES = ['OrderViewer', 'OrderCanceller']
USER_EXT = 'urn:ietf:params:scim:schemas:oracle:idcs:extension:user:User'
DESC = 'Self-paced OUT1015 MCP lab; remove with setup.py teardown'


def say(msg):
    print(f'[{time.strftime("%H:%M:%S")}] {msg}', flush=True)


def private_write(path, value):
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'w') as f:
        json.dump(value, f, indent=2)


def load():
    p = STATE / 'state.json'
    return json.loads(p.read_text()) if p.exists() else {'owned': {}}


def save(st):
    private_write(STATE / 'state.json', st)


def oci_auth():
    if os.environ.get('AIW_OCI_CONFIG'):
        cfg = oci.config.from_file(os.environ['AIW_OCI_CONFIG'], os.environ.get('AIW_OCI_PROFILE', 'DEFAULT'))
        signer = oci.signer.Signer(cfg['tenancy'], cfg['user'], cfg['fingerprint'], cfg['key_file'], cfg.get('pass_phrase'))
        return cfg, signer
    if not os.environ.get('OCI_CLI_CONFIG_FILE'):
        sys.exit('Run this in OCI Cloud Shell (or set AIW_OCI_CONFIG to an API-key config file).')
    cfg = oci.config.from_file(os.environ['OCI_CLI_CONFIG_FILE'], os.environ.get('OCI_CLI_PROFILE', 'DEFAULT'))
    token = Path(cfg['delegation_token_file']).read_text().strip()
    return cfg, oci.auth.signers.InstancePrincipalsDelegationTokenSigner(delegation_token=token)


class Domain:
    def __init__(self, name=None, url=None):
        self.cfg, self.signer = oci_auth()
        iam = oci.identity.IdentityClient(self.cfg, signer=self.signer)
        if not url:
            domains = oci.pagination.list_call_get_all_results(iam.list_domains, self.cfg['tenancy']).data
            match = [d for d in domains if d.display_name == (name or 'Default') and d.lifecycle_state == 'ACTIVE']
            if not match:
                sys.exit(f'No active identity domain named {name!r} in the root compartment. '
                         f"Available: {', '.join(d.display_name for d in domains)}")
            url = match[0].url
        self.url = url.replace(':443', '').rstrip('/')
        from oci._vendor import requests
        self.http = requests.Session()
        self.http.auth = self.signer

    def call(self, method, path, body=None, params=None, ok=(200, 201, 204)):
        r = self.http.request(method, self.url + '/admin/v1/' + path, json=body, params=params, timeout=30, allow_redirects=False)
        if r.status_code not in ok:
            # Never print response bodies: app responses can contain client secrets.
            raise SystemExit(f'{method} {path.split("/")[0]} returned HTTP {r.status_code}. '
                             'Check that you are an administrator of this identity domain.')
        return r.json() if r.content else {}


def find_user(d, username):
    if username:
        found = d.call('GET', 'Users', params={'filter': f'userName eq "{username}"', 'attributes': 'id,userName,active'})
    else:
        ocid = os.environ.get('OCI_CS_USER_OCID') or d.cfg.get('user')
        found = d.call('GET', 'Users', params={'filter': f'ocid eq "{ocid}"', 'attributes': 'id,userName,active'})
    users = found.get('Resources', [])
    if not users:
        sys.exit('The lab user was not found in this domain. Pass --user <username> of a user in the domain.')
    return users[0]


def build(domain_name, username):
    st = load()
    d = Domain(domain_name, st.get('domain_url'))
    user = find_user(d, username or st.get('username'))
    if st.get('domain_url') and (st['domain_url'] != d.url or st['user_id'] != user['id']):
        sys.exit('This lab was already prepared for another domain or user; run teardown first.')
    st.update(domain_url=d.url, user_id=user['id'], username=user['userName'])
    save(st)
    owned = st['owned']
    for name in APP_NAMES:
        apps = d.call('GET', 'Apps', params={'filter': f'displayName eq "{name}"', 'attributes': 'id'}).get('Resources', [])
        if apps and not any(a['id'] == owned.get(name) for a in apps):
            sys.exit(f'An app named "{name}" already exists and was not created by this script. Delete or rename it first.')

    def create(key, collection, body):
        if key in owned:
            return d.call('GET', collection + '/' + owned[key])
        res = d.call('POST', collection, body)
        owned[key] = res['id']
        if res.get('clientSecret'):
            st.setdefault('secrets', {})[key] = res['clientSecret']
        save(st)
        say(f'Created {key}')
        return res

    common = {'schemas': ['urn:ietf:params:scim:schemas:oracle:idcs:App'],
              'basedOnTemplate': {'value': 'CustomWebAppTemplateId'}, 'description': DESC, 'active': True,
              'showInMyApps': False, 'allowOffline': False, 'trustScope': 'Explicit'}
    resource = create(APP_NAMES[0], 'Apps', {**common, 'displayName': APP_NAMES[0], 'isUnmanagedApp': True,
        'isOAuthResource': True, 'isOAuthClient': False, 'audience': RESOURCE_URI, 'accessTokenExpiry': 300,
        'allowAccessControl': True, 'scopes': [{'value': '/orders.invoke', 'displayName': 'Invoke order tools',
        'description': 'Enter the order service; each tool checks its own role', 'requiresConsent': False}]})
    client = create(APP_NAMES[1], 'Apps', {**common, 'displayName': APP_NAMES[1], 'isOAuthClient': True,
        'isOAuthResource': False, 'clientType': 'confidential', 'allowedGrants': ['authorization_code'],
        'allUrlSchemesAllowed': True, 'redirectUris': [REDIRECT], 'allowedScopes': [{'fqs': SCOPE}],
        'allowAccessControl': True, 'bypassConsent': True})
    roles = {}
    for name in ROLES:
        roles[name] = create(name, 'AppRoles', {'schemas': ['urn:ietf:params:scim:schemas:oracle:idcs:AppRole'],
            'displayName': name, 'description': DESC, 'adminRole': False, 'public': False, 'availableToUsers': True,
            'availableToGroups': True, 'availableToClients': False, 'app': {'value': resource['id']}})
    create('viewer grant', 'Grants', {'schemas': ['urn:ietf:params:scim:schemas:oracle:idcs:Grant'],
        'grantMechanism': 'ADMINISTRATOR_TO_USER', 'app': {'value': resource['id']},
        'grantee': {'type': 'User', 'value': user['id']},
        'entitlement': {'attributeName': 'appRoles', 'attributeValue': roles['OrderViewer']['id']}})
    create('client access grant', 'Grants', {'schemas': ['urn:ietf:params:scim:schemas:oracle:idcs:Grant'],
        'grantMechanism': 'ADMINISTRATOR_TO_USER', 'app': {'value': client['id']},
        'grantee': {'type': 'User', 'value': user['id']}})
    create('role claim', 'CustomClaims', {'schemas': ['urn:ietf:params:scim:schemas:oracle:idcs:CustomClaim'],
        'name': CLAIM, 'value': '$user.' + USER_EXT + '.appRoles.*.value', 'expression': True, 'mode': 'always',
        'tokenType': 'AT', 'allScopes': False, 'scopes': [SCOPE]})
    configuration = {
        'prepared_at_utc': datetime.now(timezone.utc).isoformat(), 'domain_url': d.url,
        'resource_app_id': resource['id'], 'client_app_id': client['id'], 'client_id': client['name'],
        'client_secret': st['secrets'][APP_NAMES[1]], 'redirect_uri': REDIRECT,
        'role_ids': {'OrderViewer': roles['OrderViewer']['id'], 'OrderCanceller': roles['OrderCanceller']['id']},
        'role_claim': CLAIM, 'expected_audience': RESOURCE_URI, 'resource_uri': RESOURCE_URI, 'required_scope': SCOPE,
        'resource_scope_value': '/orders.invoke', 'asha_user_id': user['id'],
        'user_label': user['userName'], 'mcp_endpoint': RESOURCE_URI}
    private_write(CONFIG_OUT, {'configuration': configuration})
    say(f'Wrote {CONFIG_OUT.name}. Download it to your laptop (Cloud Shell menu > Download, path {CONFIG_OUT}).')
    return status()


def status():
    st = load()
    if not st.get('domain_url'):
        sys.exit('Nothing prepared yet; run build.')
    d = Domain(url=st['domain_url'])
    data = d.call('GET', 'Users/' + st['user_id'], params={'attributes': USER_EXT + ':appRoles'})
    held = {r['value'] for r in data.get(USER_EXT, {}).get('appRoles', [])}
    names = {st['owned'][r]: r for r in ROLES if r in st['owned']}
    have = [names[v] for v in held if v in names]
    print(f"Lab user {st['username']}: {', '.join(sorted(have)) or 'no order roles'}")
    ok = have == ['OrderViewer']
    print('MCP lab: STARTING STATE (Viewer only)' if ok else 'MCP lab: not at the starting state (run reset)')
    return ok


def reset():
    st = load()
    d = Domain(url=st['domain_url'])
    canceller = st['owned'].get('OrderCanceller')
    grants = d.call('GET', 'Grants', params={'filter': f'grantee.value eq "{st["user_id"]}" and app.value eq "{st["owned"][APP_NAMES[0]]}"',
                                             'attributes': 'id,entitlement'}).get('Resources', [])
    for g in grants:
        if g.get('entitlement', {}).get('attributeValue') == canceller:
            d.call('DELETE', 'Grants/' + g['id'])
            say('Removed the OrderCanceller grant')
    time.sleep(5)
    return status()


def teardown():
    st = load()
    if not st.get('domain_url'):
        say('Nothing to remove.')
        return
    d = Domain(url=st['domain_url'])
    owned = st['owned']
    # Grants first (including any Canceller grant added in the Console), then claim, roles, apps.
    for app_key in APP_NAMES:
        if app_key in owned:
            for g in d.call('GET', 'Grants', params={'filter': f'app.value eq "{owned[app_key]}"', 'attributes': 'id'}).get('Resources', []):
                d.call('DELETE', 'Grants/' + g['id'], ok=(200, 204, 404))
    for key, coll in [('role claim', 'CustomClaims'), ('OrderViewer', 'AppRoles'), ('OrderCanceller', 'AppRoles')]:
        if key in owned:
            d.call('DELETE', f'{coll}/{owned[key]}', ok=(200, 204, 404))
            say(f'Deleted {key}')
    for key in reversed(APP_NAMES):
        if key in owned:
            d.call('PUT', 'AppStatusChanger/' + owned[key], {'schemas': ['urn:ietf:params:scim:schemas:oracle:idcs:AppStatusChanger'],
                   'active': False}, ok=(200, 201, 204, 404))
            d.call('DELETE', 'Apps/' + owned[key], ok=(200, 204, 404))
            say(f'Deleted {key}')
    CONFIG_OUT.unlink(missing_ok=True)
    (STATE / 'state.json').unlink(missing_ok=True)
    say('Teardown complete.')
    print('Delete mcp-lab-config.json from your laptop as well.')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('command', choices=['build', 'status', 'reset', 'teardown'])
    ap.add_argument('--domain', help='identity domain display name (default: Default)')
    ap.add_argument('--user', help='username of the lab user in that domain (default: you)')
    ap.add_argument('--yes', action='store_true')
    a = ap.parse_args()
    if a.command == 'build':
        build(a.domain, a.user)
    elif a.command == 'status':
        status()
    elif a.command == 'reset':
        reset()
    else:
        if not a.yes:
            sys.exit('teardown deletes the lab apps, roles, grants and claim; rerun with --yes')
        teardown()


if __name__ == '__main__':
    main()
