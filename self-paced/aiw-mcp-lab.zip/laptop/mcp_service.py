#!/usr/bin/env python3
"""Real MCP Streamable HTTP service. All tools/call requests are authorized."""
import asyncio
import json
from pathlib import Path

import jsonschema
from mcp import MCPError
from mcp.server import Server
from mcp.server.auth.middleware.auth_context import get_access_token
from mcp.server.auth.provider import AccessToken
from mcp.server.auth.settings import AuthSettings
from mcp.server.transport_security import TransportSecuritySettings
import mcp.types as types
from starlette.responses import JSONResponse
from starlette.routing import Route

from orders import Orders
from token_auth import OracleUserTokens, Principal, TokenRejected

HERE=Path(__file__).resolve().parent


def create_service(config,store=None,validator=None):
    validator=validator or OracleUserTokens(config)
    store=store or Orders(config,HERE/'.local/orders.sqlite3')
    contracts=json.loads((HERE/'contracts/tools.json').read_text())['tools']
    by_name={tool['name']:tool for tool in contracts}

    class UserVerifier:
        async def verify_token(self,token):
            try:
                principal=await asyncio.to_thread(validator.verify,token,require_scope=False)
            except TokenRejected:
                return None
            return AccessToken(token=token,client_id=config['client_id'],
                scopes=list(principal.scopes),expires_at=principal.expires_at,
                resource=config['resource_uri'],subject=principal.user_id,
                claims={'iss':principal.issuer,'user_id':principal.user_id,
                        'role_ids':list(principal.role_ids),'exp':principal.expires_at,'iat':principal.issued_at})

    async def list_tools(ctx,params):
        return types.ListToolsResult(tools=[types.Tool(**tool) for tool in contracts])

    async def call_tool(ctx,params):
        token=get_access_token()
        # Transport middleware establishes this context on EVERY HTTP request.
        if token is None or not token.claims:
            raise ValueError('Authentication context required')
        claim=token.claims
        principal=Principal(claim['iss'],claim['user_id'],frozenset(claim['role_ids']),claim['exp'],claim['iat'])
        tool=by_name.get(params.name)
        if tool is None: raise MCPError(-32602,'Unknown tool')
        args=params.arguments or {}
        try:
            jsonschema.validate(args,tool['inputSchema'])
        except jsonschema.ValidationError:
            # ValidationError's default string includes caller input. Keep both
            # protocol errors and server logs free of arbitrary argument bodies.
            raise MCPError(-32602,'Invalid tool arguments') from None
        result=await asyncio.to_thread(store.view,principal,args['order_id']) if params.name=='view_order' else \
            await asyncio.to_thread(store.cancel,principal,**args)
        error=result['code'] not in ('ORDER_VIEWED','ORDER_CANCELLED')
        text= ('Cancellation not permitted. Your account does not have the cancellation role.'
               if result['code']=='ORDER_PERMISSION_DENIED' and params.name=='cancel_order'
               else json.dumps(result))
        return types.CallToolResult(content=[types.TextContent(type='text',text=text)],
                                    structuredContent=result,isError=error)

    server=Server('Summit Orders MCP',version='0.1.0',on_list_tools=list_tools,on_call_tool=call_tool)
    async def metadata(request):
        # Oracle advertises a shared issuer string; pin the domain-specific
        # discovery location rather than discovering an arbitrary other domain.
        return JSONResponse({'resource':config['resource_uri'],
            'authorization_servers':[config['domain_url']], 'scopes_supported':[config['required_scope']],
            'bearer_methods_supported':['header']},headers={'Cache-Control':'no-store'})
    app=server.streamable_http_app(streamable_http_path='/orders-mcp',json_response=True,
        stateless_http=True,max_request_body_size=8192,
        host='127.0.0.1',token_verifier=UserVerifier(),
        auth=AuthSettings(issuer_url=config['domain_url'],resource_server_url=config['resource_uri'],
                          required_scopes=[config['required_scope']],validate_token_resource=True),
        transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=True,
            allowed_hosts=['127.0.0.1:8892'],
            allowed_origins=['http://127.0.0.1:8891']),
    )
    # Replace SDK metadata with the explicit domain-bound metadata above.
    for route in app.routes:
        if getattr(route,'path','').startswith('/.well-known/oauth-protected-resource'):
            route.endpoint=metadata
            route.app=Route(route.path,endpoint=metadata).app
    return app


if __name__=='__main__':
    import uvicorn
    config=json.loads((HERE/'.local/iam-owned.json').read_text())['configuration']
    # No token is minted or fabricated on startup. Seed ownership only; actual
    # authorization still requires an Oracle-signed token on each MCP request.
    store=Orders(config,HERE/'.local/orders.sqlite3')
    owner=Principal('https://identity.oraclecloud.com/',config['asha_user_id'],frozenset(),0,0)
    store.seed(owner)
    uvicorn.run(create_service(config,store),host='127.0.0.1',port=8892,access_log=False,log_level='warning')
