# Summit Retail order tools (laptop part of the self-paced MCP lab)

Needs Python 3.10 or later.

    python3 -m venv .venv
    . .venv/bin/activate            # Windows: .venv\Scripts\activate
    pip install -r requirements.txt
    python3 start.py --config <path to mcp-lab-config.json>

Then open http://127.0.0.1:8891/ in a private browser window and follow the activity guide.
