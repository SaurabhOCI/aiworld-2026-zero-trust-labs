"""Oracle Identity Domains sign-in; portal sessions never contain OAuth tokens."""
import hmac
import secrets
import time
from urllib.parse import urlsplit

from authlib.integrations.flask_client import OAuth, OAuthError
from authlib.integrations.flask_client.apps import FlaskOAuth2App
from authlib.common.errors import AuthlibBaseError
from flask import abort, current_app, redirect, render_template, request, session, url_for
from joserfc.errors import JoseError
from requests.exceptions import RequestException


class OracleOAuth2App(FlaskOAuth2App):
    def fetch_jwk_set(self, force=False):
        """Oracle can require authentication even for its public signing keys."""
        metadata = self.load_server_metadata()
        if metadata.get("jwks") and not force:
            return metadata["jwks"]
        uri = metadata.get("jwks_uri", "")
        endpoint = urlsplit(uri)
        domain = urlsplit(current_app.config["SSO_DOMAIN_URL"])
        if (endpoint.scheme != "https" or endpoint.hostname != domain.hostname or
                (endpoint.port or 443) != (domain.port or 443) or endpoint.username or
                endpoint.password or endpoint.fragment):
            raise ValueError("Signing keys must come from the configured identity domain.")
        # Authlib stores the just-issued token in Flask's request-local g.
        # Use it only at this same-domain endpoint, never follow a redirect.
        token = self.token
        if not token or not token.get("access_token"):
            raise ValueError("The signing-key request requires the current access token.")
        response = self.get(uri, token=token, allow_redirects=False, timeout=15)
        response.raise_for_status()
        if response.status_code != 200:
            raise ValueError("Unexpected signing-key response.")
        jwks = response.json()
        if not isinstance(jwks, dict) or not jwks.get("keys"):
            raise ValueError("The signing-key response contains no keys.")
        self.server_metadata["jwks"] = jwks
        return jwks


def configure_sso(app, db, session_digest):
    enabled = app.config["SSO_ENABLED"]
    oauth = OAuth(app)
    if enabled:
        for key in ("SSO_DOMAIN_URL", "SSO_CLIENT_ID", "SSO_CLIENT_SECRET", "SSO_REDIRECT_URI"):
            if not app.config.get(key):
                raise RuntimeError(f"{key} is required when Oracle SSO is enabled.")
        domain = urlsplit(app.config["SSO_DOMAIN_URL"])
        callback = urlsplit(app.config["SSO_REDIRECT_URI"])
        if (domain.scheme != "https" or not domain.hostname or domain.username or
                domain.password or domain.path not in ("", "/") or domain.query or domain.fragment):
            raise RuntimeError("SSO_DOMAIN_URL must be the identity domain HTTPS origin.")
        if (callback.scheme != "https" or callback.hostname not in app.config["TRUSTED_HOSTS"] or
                callback.path != "/auth/oracle/callback" or callback.username or
                callback.password or callback.query or callback.fragment):
            raise RuntimeError("Register the exact trusted HTTPS SSO callback URL.")
        oauth.register(
            "oracle",
            client_cls=OracleOAuth2App,
            client_id=app.config["SSO_CLIENT_ID"],
            client_secret=app.config["SSO_CLIENT_SECRET"],
            server_metadata_url=app.config["SSO_DOMAIN_URL"].rstrip("/") + "/.well-known/openid-configuration",
            client_kwargs={"scope": "openid profile", "code_challenge_method": "S256",
                           "token_endpoint_auth_method": "client_secret_basic", "timeout": 15},
        )

    def revoke_portal_session():
        token = session.get("login_token")
        if token:
            digest = session_digest(token)
            db().execute("DELETE FROM login_sessions WHERE token_hash=?", (digest,))
            db().execute("DELETE FROM sso_sessions WHERE token_hash=?", (digest,))
            db().commit()
        session.clear()

    def failed_signin(status=403, stage="callback", error=None):
        # Never render provider errors, authorization codes or token contents.
        response = getattr(error, "response", None)
        http_status = getattr(response, "status_code", None)
        # Only fixed stage names, exception classes and numeric status codes.
        # Do not log exception messages: they can contain tokens or request URLs.
        app.logger.warning("SSO_SIGNIN_FAILED stage=%s type=%s http_status=%s", stage,
                           type(error).__name__ if error else "Rejected", http_status)
        revoke_portal_session()
        return render_template("sso_error.html"), status

    @app.post("/auth/oracle")
    def oracle_login():
        if not enabled:
            abort(404)
        revoke_portal_session()
        nonce = secrets.token_urlsafe(32)
        session["sso_nonce"] = nonce
        session["sso_started_at"] = time.time()
        try:
            return oauth.oracle.authorize_redirect(app.config["SSO_REDIRECT_URI"], nonce=nonce)
        except (OAuthError, AuthlibBaseError, JoseError, RequestException, ValueError) as error:
            return failed_signin(503, "authorization_start", error)

    @app.get("/auth/oracle/callback")
    def oracle_callback():
        if not enabled:
            abort(404)
        nonce = session.get("sso_nonce", "")
        started = session.get("sso_started_at", 0)
        if (not nonce or not isinstance(started, (int, float)) or
                not 0 <= time.time() - started <= 300 or
                request.args.get("error") or not request.args.get("code")):
            return failed_signin(stage="callback_parameters_or_session")
        stage = "token_exchange_or_validation"
        try:
            # Authlib checks state, the domain's signing key, issuer, audience,
            # expiry and nonce before supplying userinfo from the ID token.
            token = oauth.oracle.authorize_access_token(leeway=30)
            claims = token.get("userinfo")
            if (not claims or not isinstance(claims.get("sub"), str) or not claims["sub"] or
                    not isinstance(claims.get("nonce"), str) or
                    not hmac.compare_digest(claims["nonce"].encode(), nonce.encode())):
                return failed_signin(stage="subject_or_nonce")
            expires = min(float(claims["exp"]), time.time() + app.config["SSO_SESSION_SECONDS"])
            if expires <= time.time():
                return failed_signin(stage="expired_identity")
            stage = "profile_fetch"
            profile = oauth.oracle.userinfo(token=token)
            if not profile or profile.get("sub") != claims["sub"]:
                return failed_signin(stage="profile_subject")
            # The domain itself enforces application assignment. Never merge
            # this identity with a local account by username or email address.
            username = str(profile.get("preferred_username") or claims["sub"])[:255]
            display = str(profile.get("name") or claims.get("user_displayname") or
                          profile.get("given_name") or username)[:255]
            principal = (app.config["SSO_DOMAIN_URL"].rstrip("/"), claims["iss"], claims["sub"])
        except (OAuthError, AuthlibBaseError, JoseError, RequestException, ValueError, KeyError, TypeError) as error:
            return failed_signin(stage=stage, error=error)
        revoke_portal_session()
        portal_token = secrets.token_urlsafe(32)
        db().execute("DELETE FROM sso_sessions WHERE expires_at<=?", (time.time(),))
        db().execute(
            "INSERT INTO sso_sessions(token_hash,domain,issuer,subject,username,display_name,role,expires_at) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (session_digest(portal_token), *principal, username, display, "Support specialist", expires),
        )
        db().commit()
        session["login_token"] = portal_token
        session["auth_method"] = "sso"
        session.permanent = True
        return redirect(url_for("dashboard"))

    return oauth
