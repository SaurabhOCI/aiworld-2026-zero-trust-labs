#!/usr/bin/env python3
"""Local browser rehearsal: real Oracle sign-in and real MCP calls.

Separate from the deployed Incident-01 portal. Uses only loopback service ports,
synthetic orders and the prepared Orders OAuth client. No OCI API key is used.
"""
from datetime import datetime,timezone
import json
import logging
import os
from pathlib import Path
import secrets
import threading
import time

from flask import abort,redirect,render_template,request,session

from claim_check import create_app,HERE
from mcp_client import OrderTools
from orders import Orders
from token_auth import Principal


def create_rehearsal(config=None,*,tools=None,store=None,evidence_file=None):
    app=create_app(config)
    cfg=app.extensions['orders_config']
    tools=tools or OrderTools(cfg)
    store=store or Orders(cfg,HERE/'.local/orders.sqlite3')
    store.seed(Principal('https://identity.oraclecloud.com/',cfg['asha_user_id'],frozenset(),0,0))
    cache=app.extensions['orders_token_cache']
    evidence_file=Path(evidence_file or HERE/'.local/mcp-rehearsal-events.json')
    evidence_lock=threading.Lock()
    app.extensions['orders_rehearsal_store']=store

    def connected():
        sid=session.get('sid','')
        entry=cache.get(sid)
        if entry and entry['principal'].expires_at>time.time():
            return entry
        if sid:
            cache.pop(sid,None)
            store.forget_session(sid)
            session.pop('sid',None)
        return None

    def required():
        entry=connected()
        if entry is None: abort(401,description='Reconnect order tools to continue.')
        return entry

    def record(entry,tool,outcome,before=None,after=None):
        event={'at_utc':datetime.now(timezone.utc).isoformat(),
            'authentication_source':entry['summary']['source'],
            'transport':tools.kind,'user':cfg.get('user_label','Asha'),'tool':tool,
            'available_tools':list(outcome.tools),
            'token_issued_at':entry['principal'].issued_at,
            'approved_user_roles':[name for name,rid in cfg['role_ids'].items()
                                   if rid in entry['principal'].role_ids],
            'result_code':outcome.result['code'],'is_error':outcome.is_error,
            'changed':outcome.result.get('changed',False),
            'order_before':before,'order_after':after,
            'correlation_id':outcome.result.get('correlation_id')}
        with evidence_lock:
            events=json.loads(evidence_file.read_text()) if evidence_file.exists() else []
            events.append(event)
            evidence_file.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
            tmp=evidence_file.with_suffix('.tmp')
            with os.fdopen(os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600),'w') as f:
                json.dump(events[-100:],f,indent=2)
                f.write('\n')
            os.replace(tmp,evidence_file)

    def unavailable(entry,error):
        logging.getLogger('orders').warning('MCP operation unavailable: %s',type(error).__name__)
        entry['message']=('unavailable','Order tools are unavailable. Reconnect and try again.')

    @app.before_request
    def revoke_confirmations():
        # Registered after the helper's CSRF guard: rejected POSTs do not revoke.
        if request.method=='POST' and request.endpoint in ('connect','disconnect'):
            sid=session.get('sid','')
            if sid: store.forget_session(sid)

    def index():
        session.setdefault('csrf',secrets.token_urlsafe(32))
        entry=connected()
        if entry: entry.pop('intent',None)  # returning to the order aborts an open prompt
        message=entry.pop('message',None) if entry else None
        error=session.pop('error',None)
        return render_template('rehearsal.html',entry=entry,message=message,error=error,
            csrf=session['csrf'],confirmation=None,
            tool_roles={'view_order':'OrderViewer','cancel_order':'OrderCanceller'})
    app.view_functions['index']=index

    @app.post('/orders/view')
    def view_order():
        entry=required()
        try:
            outcome=tools.call(entry['token'],'view_order',{'order_id':'SR-1042'})
            entry['last_tools']=outcome.tools
            entry['last_result']=outcome.result
            entry['order']=outcome.result.get('order') if not outcome.is_error else None
            entry['message']=('success','Order viewed successfully.') if not outcome.is_error else ('denied','This order is unavailable.')
            record(entry,'view_order',outcome,after=entry['order'])
        except Exception as error:
            unavailable(entry,error)
        return redirect('/')

    @app.post('/orders/cancel')
    def cancellation_prompt():
        entry=required()
        order=entry.get('order')
        if not order or order.get('status')!='PENDING':
            entry['message']=('unavailable','View a pending order before requesting cancellation.')
            return redirect('/')
        intent={'operation_id':secrets.token_urlsafe(24),'version':order['version'],
                'expires':time.time()+60}
        entry['intent']=intent
        return render_template('rehearsal.html',entry=entry,message=None,error=None,
            csrf=session['csrf'],confirmation=intent,
            tool_roles={'view_order':'OrderViewer','cancel_order':'OrderCanceller'})

    @app.post('/orders/cancel/confirm')
    def confirm_cancellation():
        entry=required()
        intent=entry.get('intent')
        if (not intent or time.time()>=intent['expires']
                or request.form.get('operation_id')!=intent['operation_id']):
            abort(400,description='Cancellation confirmation expired. Start again.')
        entry.pop('intent',None)
        try:
            before=tools.call(entry['token'],'view_order',{'order_id':'SR-1042'})
            if before.is_error: raise ValueError('Order unavailable')
            reference=store.confirm(entry['principal'],session['sid'],'SR-1042',
                                    intent['version'],intent['operation_id'])
            result=tools.call(entry['token'],'cancel_order',{
                'order_id':'SR-1042','expected_version':intent['version'],
                'operation_id':intent['operation_id'],'confirmation_ref':reference})
            after=tools.call(entry['token'],'view_order',{'order_id':'SR-1042'})
            entry['last_tools']=result.tools
            entry['last_result']=result.result
            entry['order']=after.result.get('order') if not after.is_error else None
            if result.result['code']=='ORDER_PERMISSION_DENIED':
                entry['message']=('denied','Cancellation not permitted. Your account does not have the cancellation role.')
            elif result.result['code']=='ORDER_CANCELLED':
                entry['message']=('success','Order SR-1042 has been cancelled.')
            else:
                entry['message']=('unavailable','The order could not be cancelled. View its latest status and try again.')
            record(entry,'cancel_order',result,before.result.get('order'),entry['order'])
        except Exception as error:
            unavailable(entry,error)
        return redirect('/')

    @app.post('/disconnect')
    def disconnect():
        cache.pop(session.get('sid',''),None)
        session.clear()
        return redirect('/')

    @app.errorhandler(401)
    def reconnect_required(error):
        session['error']='Your order connection has expired. Connect with Oracle SSO to continue.'
        return redirect('/')

    return app


if __name__=='__main__':
    logging.getLogger('werkzeug').disabled=True
    create_rehearsal().run(host='127.0.0.1',port=8891,debug=False,use_reloader=False)
