"""Strict Oracle user access-token adapter; no portal display-name authorization."""
from dataclasses import dataclass
import re
import threading
import time
from urllib.parse import urlsplit

import jwt
import requests


class TokenRejected(Exception):
    pass


@dataclass(frozen=True)
class Principal:
    issuer: str
    user_id: str
    role_ids: frozenset[str]
    expires_at: int
    issued_at: int
    scopes: frozenset[str] = frozenset()


class OracleUserTokens:
    def __init__(self, config, *, clock=time.time):
        self.config = config
        self.clock = clock
        self.keys = {}
        self.keys_until = 0
        self.last_refresh = 0
        self.lock = threading.Lock()
        self.metadata = None

    def discovery(self):
        if self.metadata is None:
            domain = self.config['domain_url'].rstrip('/')
            response = requests.get(domain+'/.well-known/openid-configuration',
                                    timeout=12, allow_redirects=False)
            response.raise_for_status()
            metadata = response.json()
            if metadata.get('issuer') != 'https://identity.oraclecloud.com/':
                raise TokenRejected('Unexpected configured-domain issuer')
            expected = urlsplit(domain)
            for name in ('jwks_uri','authorization_endpoint','token_endpoint','userinfo_endpoint'):
                try:
                    parsed = urlsplit(metadata[name])
                    same_origin = (parsed.scheme == expected.scheme == 'https'
                        and parsed.hostname == expected.hostname
                        and (parsed.port if parsed.port is not None else 443)
                            == (expected.port if expected.port is not None else 443)
                        and not (parsed.username or parsed.password or parsed.fragment))
                except (KeyError, ValueError, TypeError):
                    same_origin = False
                if not same_origin:
                    raise TokenRejected('Unexpected discovery endpoint')
            self.metadata = metadata
        return self.metadata

    def _key(self, kid, token):
        with self.lock:
            now = self.clock()
            if (kid not in self.keys or now >= self.keys_until) and now-self.last_refresh >= 5:
                self.last_refresh = now
                response = requests.get(self.discovery()['jwks_uri'],
                    headers={'Authorization':'Bearer '+token}, timeout=12, allow_redirects=False)
                response.raise_for_status()
                keys = response.json().get('keys', [])
                if not isinstance(keys, list) or len(keys) > 50:
                    raise TokenRejected('Invalid signing keys')
                self.keys = {k['kid']:jwt.PyJWK.from_dict(k).key for k in keys
                             if k.get('kty') == 'RSA' and k.get('use','sig') == 'sig'
                             and k.get('alg','RS256') == 'RS256' and isinstance(k.get('kid'),str)}
                self.keys_until = now+300
            if kid not in self.keys:
                raise TokenRejected('Unknown signing key')
            return self.keys[kid]

    def verify(self, token, *, require_scope=True):
        claims = None
        try:
            if not isinstance(token, str) or len(token) > 32000:
                raise TokenRejected('Invalid access token')
            header = jwt.get_unverified_header(token)
            if header.get('alg') != 'RS256' or not isinstance(header.get('kid'),str):
                raise TokenRejected('Unapproved signing algorithm')
            claims = jwt.decode(token, self._key(header['kid'],token), algorithms=['RS256'],
                audience=self.config['expected_audience'], issuer=self.discovery()['issuer'],
                leeway=10, options={'require':['exp','iat','iss','aud','user_id','client_id','sub_type','tok_type']})
            return self.principal(claims,require_scope=require_scope)
        except TokenRejected as error:
            if claims is not None:
                # Only summarize claims AFTER cryptographic/issuer/audience/time
                # validation. Never retain the JWT, user identity or full payload.
                error.diagnostics = self.sanitized_claims(claims)
            raise
        except (jwt.PyJWTError, requests.RequestException, ValueError, TypeError, KeyError):
            raise TokenRejected('Access token could not be verified') from None

    def sanitized_claims(self, claims):
        scope = claims.get('scope')
        role_ids = claims.get(self.config['role_claim'])
        return {'signature_issuer_audience_time_verified':True,
            'scope_type':type(scope).__name__,
            'scope_values':scope.split() if isinstance(scope,str) and len(scope)<=2000 else None,
            'resource_scope_fully_qualified':self.config['required_scope'],
            'resource_scope_value':self.config.get('resource_scope_value'),
            'role_claim_type':type(role_ids).__name__,
            'approved_user_role_matches':[name for name,value in self.config['role_ids'].items()
                if isinstance(role_ids,list) and value in role_ids],
            'user_matches_prepared_asha':claims.get('user_id')==self.config.get('asha_user_id'),
            'registered_client_matches':claims.get('client_id')==self.config['client_id']}

    def principal(self, claims, *, require_scope=True):
        """Called only after signature verification; exposed separately for negative tests."""
        cfg = self.config
        if (claims.get('tok_type') != 'AT' or claims.get('sub_type') != 'user'
                or claims.get('client_id') != cfg['client_id']):
            raise TokenRejected('A user access token from the registered client is required')
        user_id = claims.get('user_id')
        if not isinstance(user_id,str) or not re.fullmatch(r'[a-f0-9]{32}',user_id):
            raise TokenRejected('Missing immutable user identity')
        scope = claims.get('scope')
        if not isinstance(scope,str):
            raise TokenRejected('Missing resource scope')
        scopes = set(scope.split())
        # RFC 8707/Oracle may return the resource-local scope when `resource`
        # was supplied. Map ONLY the exact scope value read from this resource
        # app, after verify() has validated its audience; never suffix-match URLs.
        local_scope = cfg.get('resource_scope_value')
        if isinstance(local_scope,str) and local_scope and local_scope in scopes:
            scopes.add(cfg['required_scope'])
        if require_scope and cfg['required_scope'] not in scopes:
            raise TokenRejected('Missing resource scope')
        role_ids = claims.get(cfg['role_claim'])
        if not isinstance(role_ids,list) or len(role_ids) > 200 or any(
                not isinstance(r,str) or not re.fullmatch(r'[a-f0-9]{32}',r) for r in role_ids):
            raise TokenRejected('Missing or malformed signed user-role projection')
        approved = frozenset(cfg['role_ids'].values())
        # IDs are globally unique, and preparation verifies each owner app. Never
        # accept display names or any role on the OAuth client as a substitute.
        return Principal(claims['iss'], user_id, frozenset(role_ids)&approved,
                         int(claims['exp']), int(claims['iat']),frozenset(scopes))
