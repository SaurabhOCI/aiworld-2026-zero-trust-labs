"""Backend-only MCP SDK client; the bearer token never reaches the browser."""
import asyncio
from dataclasses import dataclass
from urllib.parse import urlsplit

import httpx2
from mcp.client.session import ClientSession
from mcp.client.streamable_http import streamable_http_client


@dataclass(frozen=True)
class Outcome:
    tools: tuple[str,...]
    result: dict
    is_error: bool


class OrderTools:
    kind='MCP SDK Streamable HTTP'

    def __init__(self,config,*,transport=None):
        self.config=config
        self.transport=transport
        self.endpoint=config.get('mcp_endpoint','http://127.0.0.1:8892/orders-mcp')
        if self.endpoint not in ('http://127.0.0.1:8892/orders-mcp',config['resource_uri']):
            raise ValueError('Unapproved MCP endpoint')
        parsed=urlsplit(self.endpoint)
        self.metadata_url=f'{parsed.scheme}://{parsed.netloc}/.well-known/oauth-protected-resource/orders-mcp'

    async def call_async(self,token,name,arguments):
        async with httpx2.AsyncClient(transport=self.transport,timeout=15,
                                      trust_env=False,follow_redirects=False) as http:
            metadata=await http.get(self.metadata_url)
            metadata.raise_for_status()
            resource=metadata.json()
            if (resource.get('resource') != self.config['resource_uri']
                    or resource.get('authorization_servers') != [self.config['domain_url']]
                    or self.config['required_scope'] not in resource.get('scopes_supported',[])):
                raise ValueError('Unexpected MCP protected-resource metadata')
            http.headers['Authorization']='Bearer '+token
            async with streamable_http_client(self.endpoint,http_client=http) as streams:
                async with ClientSession(*streams) as client:
                    await client.initialize()
                    discovery=await client.list_tools()
                    names=tuple(tool.name for tool in discovery.tools)
                    if set(names) != {'view_order','cancel_order'} or name not in names:
                        raise ValueError('Unexpected MCP tool contract')
                    response=await client.call_tool(name,arguments)
                    result=response.structured_content
                    if not isinstance(result,dict) or not isinstance(result.get('code'),str):
                        raise ValueError('Unexpected MCP tool result')
                    return Outcome(names,result,response.is_error)

    def call(self,token,name,arguments):
        return asyncio.run(self.call_async(token,name,arguments))
