#!/usr/bin/env python3
"""Start the Summit Retail order tools on your laptop (self-paced MCP lab).

    python3 start.py --config ~/Downloads/mcp-lab-config.json   # first run: installs the config
    python3 start.py                                             # later runs
    python3 start.py --reset-orders                              # put order SR-1042 back to Pending, version 1

Starts the MCP order service on http://127.0.0.1:8892 and the browser client on
http://127.0.0.1:8891. Press Ctrl+C to stop both.
"""
import argparse
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
LOCAL = HERE / '.local'

ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
ap.add_argument('--config', help='path to mcp-lab-config.json downloaded from Cloud Shell')
ap.add_argument('--reset-orders', action='store_true')
a = ap.parse_args()
LOCAL.mkdir(mode=0o700, exist_ok=True)
if a.config:
    shutil.copyfile(os.path.expanduser(a.config), LOCAL / 'iam-owned.json')
    os.chmod(LOCAL / 'iam-owned.json', 0o600)
    print('Config installed. You can delete the downloaded copy.')
if not (LOCAL / 'iam-owned.json').exists():
    sys.exit('No config yet. Run: python3 start.py --config <path to mcp-lab-config.json>')
if a.reset_orders:
    (LOCAL / 'orders.sqlite3').unlink(missing_ok=True)
    print('Orders reset: SR-1042 starts again as Pending, version 1.')
procs = [subprocess.Popen([sys.executable, str(HERE / 'mcp_service.py')], cwd=HERE)]
time.sleep(3)
procs.append(subprocess.Popen([sys.executable, str(HERE / 'rehearsal.py')], cwd=HERE))
time.sleep(3)
print('\nOpen http://127.0.0.1:8891/ in a private browser window.')
print('Press Ctrl+C here to stop.')
try:
    while all(p.poll() is None for p in procs):
        time.sleep(1)
finally:
    for p in procs:
        p.terminate()
