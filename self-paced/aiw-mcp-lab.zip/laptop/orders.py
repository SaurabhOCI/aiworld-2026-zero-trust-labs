"""Synthetic order transactions and per-tool user-role enforcement."""
import hashlib
import json
import os
from pathlib import Path
import secrets
import sqlite3
import time
import uuid
from contextlib import contextmanager


class Orders:
    def __init__(self, config, path, *, clock=time.time):
        self.config, self.path, self.clock = config, str(path), clock
        Path(path).parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        fd = os.open(path,os.O_CREAT|os.O_RDWR,0o600)
        os.close(fd)
        os.chmod(path,0o600)
        with self.connect() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS orders(
                  id TEXT PRIMARY KEY, owner TEXT NOT NULL, product TEXT NOT NULL,
                  status TEXT NOT NULL, version INTEGER NOT NULL);
                CREATE TABLE IF NOT EXISTS confirmations(
                  ref_hash TEXT PRIMARY KEY, owner TEXT NOT NULL, session_ref TEXT NOT NULL,
                  order_id TEXT NOT NULL, version INTEGER NOT NULL, operation_id TEXT NOT NULL,
                  expires REAL NOT NULL, consumed INTEGER NOT NULL DEFAULT 0);
                CREATE TABLE IF NOT EXISTS operations(
                  id TEXT PRIMARY KEY, owner TEXT NOT NULL, args_hash TEXT NOT NULL, result TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS audit(
                  id TEXT PRIMARY KEY, at REAL NOT NULL, principal_ref TEXT NOT NULL,
                  tool TEXT NOT NULL, order_id TEXT NOT NULL, decision TEXT NOT NULL,
                  before_version INTEGER, after_version INTEGER);
            ''')

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path,timeout=10,isolation_level=None)
        db.row_factory=sqlite3.Row
        try:
            yield db
        finally:
            db.close()

    @staticmethod
    def owner(principal):
        return hashlib.sha256((principal.issuer+'\0'+principal.user_id).encode()).hexdigest()

    def seed(self, asha):
        with self.connect() as db:
            db.execute('INSERT OR IGNORE INTO orders VALUES(?,?,?,?,?)',
                       ('SR-1042',self.owner(asha),'Everyday Backpack','PENDING',1))
            db.execute('INSERT OR IGNORE INTO orders VALUES(?,?,?,?,?)',
                       ('SR-2099',hashlib.sha256(b'unassigned-negative-fixture').hexdigest(),
                        'Travel Headphones','PENDING',1))

    def result(self,code,tool,changed=False,**details):
        return {'code':code,'operation':tool,'changed':changed,**details}

    def audit(self,db,principal,tool,order_id,code,before=None,after=None):
        correlation=uuid.uuid4().hex
        db.execute('INSERT INTO audit VALUES(?,?,?,?,?,?,?,?)',
            (correlation,self.clock(),self.owner(principal),tool,order_id,code,before,after))
        return correlation

    def allowed(self,principal,tool):
        role={'view_order':'OrderViewer','cancel_order':'OrderCanceller'}[tool]
        return principal.expires_at > self.clock() and self.config['role_ids'][role] in principal.role_ids

    def view(self,principal,order_id):
        with self.connect() as db:
            if not self.allowed(principal,'view_order'):
                code='ORDER_PERMISSION_DENIED'
                return self.result(code,'view_order',correlation_id=self.audit(db,principal,'view_order',order_id,code))
            row=db.execute('SELECT id,product,status,version FROM orders WHERE id=? AND owner=?',
                           (order_id,self.owner(principal))).fetchone()
            code='ORDER_VIEWED' if row else 'ORDER_UNAVAILABLE'
            result=self.result(code,'view_order',correlation_id=self.audit(db,principal,'view_order',order_id,code))
            if row: result['order']=dict(row)
            return result

    def confirm(self,principal,session_ref,order_id,version,operation_id):
        # Called by the trusted backend after its CSRF-protected confirmation POST.
        # The reference itself is random, single-use and has no caller assertions.
        if not self.allowed(principal,'view_order'):
            raise ValueError('Order unavailable')
        with self.connect() as db:
            row=db.execute('SELECT 1 FROM orders WHERE id=? AND owner=? AND version=? AND status=?',
                (order_id,self.owner(principal),version,'PENDING')).fetchone()
            if not row: raise ValueError('Order unavailable')
            reference=secrets.token_urlsafe(32)
            db.execute('DELETE FROM confirmations WHERE expires<?',(self.clock(),))
            db.execute('INSERT INTO confirmations VALUES(?,?,?,?,?,?,?,0)',
                (hashlib.sha256(reference.encode()).hexdigest(),self.owner(principal),session_ref,
                 order_id,version,operation_id,min(self.clock()+60,principal.expires_at)))
            return reference

    def forget_session(self,session_ref):
        with self.connect() as db:
            db.execute('DELETE FROM confirmations WHERE session_ref=?',(session_ref,))

    def cancel(self,principal,order_id,expected_version,operation_id,confirmation_ref):
        owner=self.owner(principal)
        args_hash=hashlib.sha256(json.dumps([order_id,expected_version,operation_id,confirmation_ref],
                                           separators=(',',':')).encode()).hexdigest()
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            def finish(code,changed=False,before=None,after=None,**details):
                result=self.result(code,'cancel_order',changed,**details,
                    correlation_id=self.audit(db,principal,'cancel_order',order_id,code,before,after))
                db.execute('COMMIT')
                return result
            # Always authorize first, including retries; never read the order on denial.
            if not self.allowed(principal,'cancel_order'):
                return finish('ORDER_PERMISSION_DENIED')
            prior=db.execute('SELECT * FROM operations WHERE id=?',(operation_id,)).fetchone()
            if prior:
                if prior['owner'] != owner or prior['args_hash'] != args_hash:
                    return finish('OPERATION_ID_CONFLICT')
                db.execute('COMMIT')
                return json.loads(prior['result'])
            row=db.execute('SELECT * FROM orders WHERE id=? AND owner=?',(order_id,owner)).fetchone()
            if row is None: return finish('ORDER_UNAVAILABLE')
            if row['version'] != expected_version or row['status'] != 'PENDING':
                return finish('ORDER_STATE_CONFLICT')
            confirmation=db.execute('SELECT * FROM confirmations WHERE ref_hash=?',
                (hashlib.sha256(confirmation_ref.encode()).hexdigest(),)).fetchone()
            if (confirmation is None or confirmation['consumed'] or confirmation['expires'] <= self.clock()
                    or confirmation['owner'] != owner or confirmation['order_id'] != order_id
                    or confirmation['version'] != expected_version or confirmation['operation_id'] != operation_id):
                return finish('CONFIRMATION_REQUIRED')
            db.execute('UPDATE confirmations SET consumed=1 WHERE ref_hash=?',(confirmation['ref_hash'],))
            db.execute('UPDATE orders SET status=?,version=version+1 WHERE id=? AND owner=? AND version=?',
                ('CANCELLED',order_id,owner,expected_version))
            result=self.result('ORDER_CANCELLED','cancel_order',True,
                order={'id':order_id,'product':row['product'],'status':'CANCELLED','version':expected_version+1},
                correlation_id=self.audit(db,principal,'cancel_order',order_id,'ORDER_CANCELLED',
                                          expected_version,expected_version+1))
            db.execute('INSERT INTO operations VALUES(?,?,?,?)',(operation_id,owner,args_hash,json.dumps(result)))
            db.execute('COMMIT')
            return result
