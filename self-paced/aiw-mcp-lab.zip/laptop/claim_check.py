#!/usr/bin/env python3
"""Local, real Oracle authorization-code/PKCE claim check. Not the portal deployment.

Only binds 127.0.0.1. Stores access tokens in process memory. All results and logs
are sanitized. Stop this process after proof; no password is collected here.
"""
from datetime import datetime, timezone
import hashlib
import hmac
import json
import logging
from pathlib import Path
import secrets
import sys
import time

from authlib.integrations.flask_client import OAuth
from flask import Flask, abort, redirect, render_template_string, request, session

HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from sso import OracleOAuth2App
from token_auth import OracleUserTokens, TokenRejected

PAGE = '''<!doctype html><html lang="en"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Asha · IAM setup check</title>
<style>body{background:#f6f7f3;color:#203d34;font:18px system-ui;max-width:820px;margin:60px auto;padding:24px}h1{font-size:38px}button{background:#214b3e;color:white;border:0;border-radius:8px;padding:14px 20px;font:inherit;cursor:pointer}article{background:white;border:1px solid #ccd7cf;border-radius:12px;padding:24px;margin:24px 0}pre{white-space:pre-wrap;font-size:15px}.label{font-size:14px;letter-spacing:.1em}a{color:#214b3e}</style>
<p class="label">SUMMIT RETAIL · LIVE IAM SETUP CHECK</p><h1>Asha’s next action</h1>
<p>This page checks real Oracle-issued user permissions. It is separate from the existing portal and the simulated design preview.</p>
{% if error %}<article><strong>{{ error }}</strong><p>No token or password is displayed.</p></article>{% endif %}
{% if result %}<article><h2>Verified token summary</h2><pre>{{ result }}</pre></article>{% endif %}
<article><h2>Connect as Asha</h2><p>Use Asha’s Oracle SSO password on the Oracle sign-in page. If Oracle shows a different account, choose Asha.</p>
<form method="post" action="/connect"><input type="hidden" name="csrf" value="{{ csrf }}"><button>Continue with Oracle SSO</button></form></article>
<p>Application roles control the order tools. OCI Compute Allow/Deny policies do not control this custom API.</p></html>'''


def create_app(config=None):
    if config is None:
        config = json.loads((HERE/'.local/iam-owned.json').read_text())['configuration']
    app = Flask(__name__)
    app.config.update(SECRET_KEY=secrets.token_urlsafe(48), SESSION_COOKIE_NAME='summit_orders_proof',
        SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax',
        TRUSTED_HOSTS=['127.0.0.1'], MAX_CONTENT_LENGTH=4096, SSO_DOMAIN_URL=config['domain_url'])
    validator = OracleUserTokens(config)
    oauth = OAuth(app)
    oauth.register('oracle',client_cls=OracleOAuth2App,
        client_id=config['client_id'],client_secret=config['client_secret'],
        server_metadata_url=config['domain_url']+'/.well-known/openid-configuration',
        client_kwargs={'scope':'openid profile '+config['required_scope'],
                       'code_challenge_method':'S256','token_endpoint_auth_method':'client_secret_basic',
                       'timeout':15})
    cache = {}
    app.extensions['orders_token_cache'] = cache
    app.extensions['orders_validator'] = validator
    app.extensions['orders_config'] = config

    @app.before_request
    def guards():
        if request.host != '127.0.0.1:8891':
            abort(400)
        if request.method == 'POST':
            if not hmac.compare_digest(session.get('csrf','').encode(),request.form.get('csrf','').encode()) or not session.get('csrf'):
                abort(400)

    @app.after_request
    def headers(response):
        response.headers.update({'Cache-Control':'no-store','Referrer-Policy':'no-referrer',
            'X-Frame-Options':'DENY','X-Content-Type-Options':'nosniff',
            'Content-Security-Policy':"default-src 'none'; style-src 'self' 'unsafe-inline'; form-action 'self' "+config['domain_url']+"; base-uri 'none'; frame-ancestors 'none'"})
        return response

    @app.get('/')
    def index():
        session.setdefault('csrf',secrets.token_urlsafe(32))
        entry = cache.get(session.get('sid',''))
        return render_template_string(PAGE,csrf=session['csrf'],error=session.pop('error',None),
            result=json.dumps(entry['summary'],indent=2) if entry else None)

    @app.post('/connect')
    def connect():
        old_sid = session.get('sid')
        if old_sid: cache.pop(old_sid,None)
        session.clear()
        nonce = secrets.token_urlsafe(32)
        session['nonce'] = nonce
        session['started'] = time.time()
        return oauth.oracle.authorize_redirect(config['redirect_uri'],nonce=nonce,
                                                resource=config['resource_uri'],login_hint=config.get('user_label','asha'))

    @app.get('/auth/orders/callback')
    def callback():
        try:
            nonce = session.pop('nonce',None)
            started = session.pop('started',0)
            if not nonce or time.time()-started > 300 or request.args.get('error'):
                raise TokenRejected('Sign-in expired or refused. Try again.')
            token = oauth.oracle.authorize_access_token(leeway=30,resource=config['resource_uri'])
            identity = token.get('userinfo')
            if not identity or not hmac.compare_digest(identity.get('nonce',''),nonce):
                raise TokenRejected('ID-token nonce verification failed.')
            userinfo = oauth.oracle.userinfo(token=token)
            if not userinfo.get('sub') or userinfo['sub'] != identity.get('sub'):
                raise TokenRejected('User identity does not match the sign-in.')
            principal = validator.verify(token.get('access_token'))
            if principal.user_id != config['asha_user_id']:
                raise TokenRejected('This check requires the lab user Asha. Switch Oracle accounts and retry.')
            # The immutable ID is independently taken from the signed access token
            # and compared to the prepared user. A later portal build must also
            # bind the verified ID-token subject to the existing portal session.
            summary = {'checked_at_utc':datetime.now(timezone.utc).isoformat(),
                'source':'real Oracle authorization code + S256 PKCE',
                'user':config.get('user_label','Asha'),'signature_verified':True,'issuer_verified':True,
                'resource_audience_verified':True,'resource_scope_verified':True,
                'user_id_matches_prepared_asha':True,'token_type':'user access token',
                'approved_user_roles':[name for name,rid in config['role_ids'].items() if rid in principal.role_ids],
                'token_issued_at':principal.issued_at,'token_expires_at':principal.expires_at,
                'portal_session_binding':'NOT_TESTED_IN_LOCAL_CLAIM_CHECK',
                'mcp_execution':'NOT_YET_TESTED'}
            sid = secrets.token_urlsafe(32)
            cache.clear()  # one local presenter session, bounded memory
            cache[sid] = {'token':token['access_token'],'principal':principal,'summary':summary,
                          'oidc_subject':identity['sub']}
            session.clear()
            session['sid'] = sid
            (HERE/'.local/claim-proof.json').write_text(json.dumps(summary,indent=2)+'\n')
            return redirect('/')
        except Exception as error:
            # Authlib/network errors may contain tokens/codes: never log details.
            logging.getLogger('orders').warning('Claim check refused: %s',type(error).__name__)
            if isinstance(error,TokenRejected) and getattr(error,'diagnostics',None):
                diagnostic={'at_utc':datetime.now(timezone.utc).isoformat(),
                    'verification_completed':False,'reason':str(error),**error.diagnostics}
                (HERE/'.local/claim-check-diagnostic.json').write_text(json.dumps(diagnostic,indent=2)+'\n')
            session.clear()
            session['error'] = (str(error) if isinstance(error,TokenRejected)
                                else 'Oracle sign-in could not be verified. Retry or inspect the sanitized server status.')
            return redirect('/')
    return app


if __name__ == '__main__':
    logging.getLogger('werkzeug').disabled=True  # suppress OAuth callback query strings
    create_app().run(host='127.0.0.1',port=8891,debug=False,use_reloader=False)
