# Self-paced MCP lab: IAM application roles control the order tools

- `setup.py` runs in OCI Cloud Shell and prepares your identity domain (build, status, reset, teardown).
- `laptop/` runs on your laptop: the MCP order service (port 8892) and the order page (port 8891).

Follow the activity guide "Control AI Agent Tools with OCI IAM Application Roles".
