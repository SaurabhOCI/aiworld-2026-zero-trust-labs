#!/usr/bin/env python3
"""Self-paced IAM deny + SSO lab: build the Summit Retail starting state in YOUR OWN tenancy.

Run in OCI Cloud Shell (uses your Cloud Shell sign-in; no API key needed):

    python3 lab.py build --asha-email you+asha@example.com   # about 5 minutes
    python3 lab.py asha-password      # show Asha's one-time Console password (you change it at first sign-in)
    python3 lab.py ready              # read-only check of the starting state
    python3 lab.py reset              # remove the policies you added in the lab, start the VM again
    python3 lab.py teardown --yes     # delete everything this lab created

Options for build:
    --asha-email <address>        required: an address you can read, for example you+asha@yourdomain.com
    --parent <compartment-OCID>   create the lab compartment here (default: tenancy root)

What build creates, all tagged aiw-lab=iam-sso:
  compartment aiw-iam-lab, with child compartment SummitDemo
  a small private VM prod-app-01 in SummitDemo (no public IP, no internet route)
  user summit-asha in the Default identity domain, in groups SummitDevTeam and SummitTemporarySupport
  policy Summit-TemporarySupport-Use in aiw-iam-lab:
      allow group Default/SummitTemporarySupport to use instances in compartment SummitDemo
The lab itself asks you to add the read and deny policies in the Console.
"""
import argparse
import json
import os
import sys
import time
from pathlib import Path

import oci

STATE = Path(os.environ.get('AIW_STATE_DIR', Path.home() / '.aiw' / 'iam-sso'))
TAGS = {'aiw-lab': 'iam-sso'}
LAB, CHILD = 'aiw-iam-lab', 'SummitDemo'
USER = 'summit-asha'
GROUPS = ['SummitDevTeam', 'SummitTemporarySupport']
SUPPORT_POLICY = 'Summit-TemporarySupport-Use'
SUPPORT_STATEMENT = 'allow group Default/SummitTemporarySupport to use instances in compartment SummitDemo'
LAB_POLICIES = ['Summit-DevTeam-Read', 'Summit-Deny-Power']  # created by the learner during the lab
VM = 'prod-app-01'


def say(msg):
    print(f'[{time.strftime("%H:%M:%S")}] {msg}', flush=True)


def load():
    p = STATE / 'state.json'
    return json.loads(p.read_text()) if p.exists() else {}


def save(state):
    STATE.mkdir(mode=0o700, parents=True, exist_ok=True)
    p = STATE / 'state.json'
    fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'w') as f:
        json.dump(state, f, indent=2)


def oci_auth(region=None):
    """Cloud Shell delegation token by default; AIW_OCI_CONFIG/AIW_OCI_PROFILE select an API-key profile."""
    if os.environ.get('AIW_OCI_CONFIG'):
        cfg = oci.config.from_file(os.environ['AIW_OCI_CONFIG'], os.environ.get('AIW_OCI_PROFILE', 'DEFAULT'))
        if region:
            cfg['region'] = region
        return cfg, {}
    if not os.environ.get('OCI_CLI_CONFIG_FILE'):
        sys.exit('Run this in OCI Cloud Shell (or set AIW_OCI_CONFIG to an API-key config file).')
    cfg = oci.config.from_file(os.environ['OCI_CLI_CONFIG_FILE'], os.environ.get('OCI_CLI_PROFILE', 'DEFAULT'))
    token = Path(cfg['delegation_token_file']).read_text().strip()
    cfg['region'] = region or os.environ.get('OCI_REGION') or cfg.get('region')
    return cfg, {'signer': oci.auth.signers.InstancePrincipalsDelegationTokenSigner(delegation_token=token)}


class Cloud:
    def __init__(self, region=None):
        self.cfg, kw = oci_auth(region)
        self.tenancy = self.cfg['tenancy']
        iam = oci.identity.IdentityClient(self.cfg, **kw)
        home = [s.region_name for s in iam.list_region_subscriptions(self.tenancy).data if s.is_home_region][0]
        self.home = home
        self.iam = oci.identity.IdentityClient(dict(self.cfg, region=home), **kw)  # IAM writes go to the home region
        self.iam_region = iam  # availability domains are per region
        self.compute = oci.core.ComputeClient(self.cfg, **kw)
        self.vn = oci.core.VirtualNetworkClient(self.cfg, **kw)
        self.region = self.cfg['region']


def ours(obj):
    return (getattr(obj, 'freeform_tags', None) or {}).get('aiw-lab') == 'iam-sso'


def find(items, name):
    live = [i for i in items if getattr(i, 'name', getattr(i, 'display_name', None)) == name
            and getattr(i, 'lifecycle_state', 'ACTIVE') not in ('DELETED', 'DELETING', 'TERMINATED', 'TERMINATING')]
    if live and not ours(live[0]):
        sys.exit(f'"{name}" already exists and was not created by this lab. Rename or remove it, then rerun.')
    return live[0] if live else None


def wait(fetch, ok, label, every=5, timeout=900):
    end = time.time() + timeout
    while time.time() < end:
        try:
            obj = fetch()
        except oci.exceptions.ServiceError as e:
            if e.status != 404:  # new IAM objects can take a moment to become readable
                raise
            obj = None
        if obj is not None and ok(obj):
            return obj
        time.sleep(every)
    sys.exit(f'Timed out waiting for {label}.')


def token(st, key):
    """Stable retry token per create, so a rerun after an interruption never makes a duplicate."""
    import uuid
    st.setdefault('tokens', {}).setdefault(key, str(uuid.uuid4()))
    save(st)
    return st['tokens'][key]


def all_of(fn, *a, **k):
    return oci.pagination.list_call_get_all_results(fn, *a, **k).data


# ---------------------------------------------------------------- build
def build(c, email, parent):
    st = load()
    parent = st.get('parent') or parent or c.tenancy
    st.update(parent=parent, region=c.region)
    save(st)
    M = oci.identity.models

    lab = find(all_of(c.iam.list_compartments, parent), LAB)
    if not lab:
        say(f'Creating compartment {LAB}')
        lab = c.iam.create_compartment(M.CreateCompartmentDetails(compartment_id=parent, name=LAB, freeform_tags=TAGS,
              description='Self-paced IAM deny + SSO lab. Remove with lab.py teardown.'),
              opc_retry_token=token(st, 'lab')).data
    lab = wait(lambda: c.iam.get_compartment(lab.id).data, lambda x: x.lifecycle_state == 'ACTIVE', LAB)
    child = find(all_of(c.iam.list_compartments, lab.id), CHILD)
    if not child:
        say(f'Creating compartment {LAB}/{CHILD}')
        child = c.iam.create_compartment(M.CreateCompartmentDetails(compartment_id=lab.id, name=CHILD, freeform_tags=TAGS,
                description='Summit Retail workloads for the IAM lab'), opc_retry_token=token(st, 'child')).data
    child = wait(lambda: c.iam.get_compartment(child.id).data, lambda x: x.lifecycle_state == 'ACTIVE', CHILD)
    st.update(lab_id=lab.id, child_id=child.id)
    save(st)

    user = find(all_of(c.iam.list_users, c.tenancy), USER)
    if not user:
        if not email:
            sys.exit('Give an email address you can read: python3 lab.py build --asha-email you+asha@example.com')
        say(f'Creating user {USER} (Asha)')
        user = c.iam.create_user(M.CreateUserDetails(compartment_id=c.tenancy, name=USER, email=email, freeform_tags=TAGS,
               description='Asha, fictional Summit Retail support specialist (self-paced IAM lab)')).data
    st['user_id'] = user.id
    groups = {}
    for g in GROUPS:
        grp = find(all_of(c.iam.list_groups, c.tenancy), g)
        if not grp:
            say(f'Creating group {g}')
            grp = c.iam.create_group(M.CreateGroupDetails(compartment_id=c.tenancy, name=g, freeform_tags=TAGS,
                  description=f'Self-paced IAM lab: {g}')).data
        groups[g] = grp.id
        if not all_of(c.iam.list_user_group_memberships, c.tenancy, user_id=user.id, group_id=grp.id):
            c.iam.add_user_to_group(M.AddUserToGroupDetails(user_id=user.id, group_id=grp.id))
            say(f'Added {USER} to {g}')
    st['groups'] = groups
    if not st.get('asha_password'):
        st['asha_password'] = c.iam.create_or_reset_ui_password(user.id).data.password
        say('Created a one-time Console password for Asha (see: python3 lab.py asha-password)')
    save(st)

    pol = find(all_of(c.iam.list_policies, lab.id), SUPPORT_POLICY)
    if not pol:
        say(f'Creating policy {SUPPORT_POLICY} (the "forgotten" support grant)')
        time.sleep(10)  # let the new group name propagate
        pol = c.iam.create_policy(M.CreatePolicyDetails(compartment_id=lab.id, name=SUPPORT_POLICY, freeform_tags=TAGS,
              statements=[SUPPORT_STATEMENT], description='Left over from an old support task (lab story)')).data
    st['support_policy_id'] = pol.id
    save(st)

    network(c, st, child.id)
    vm = instance(c, st, child.id)
    say(f'{VM}: {vm.lifecycle_state}')
    say('Build complete.')
    return ready(c)


def network(c, st, cid):
    N = oci.core.models
    vcn = find(all_of(c.vn.list_vcns, cid), 'summit-iam-vcn')
    if not vcn:
        say('Creating a private network (no internet route)')
        vcn = c.vn.create_vcn(N.CreateVcnDetails(compartment_id=cid, display_name='summit-iam-vcn',
              cidr_blocks=['10.50.0.0/16'], freeform_tags=TAGS)).data
        wait(lambda: c.vn.get_vcn(vcn.id).data, lambda x: x.lifecycle_state == 'AVAILABLE', 'VCN')
    sub = find(all_of(c.vn.list_subnets, cid, vcn_id=vcn.id), 'summit-iam-private')
    if not sub:
        sub = c.vn.create_subnet(N.CreateSubnetDetails(compartment_id=cid, vcn_id=vcn.id, display_name='summit-iam-private',
              cidr_block='10.50.1.0/24', prohibit_public_ip_on_vnic=True, freeform_tags=TAGS)).data
        wait(lambda: c.vn.get_subnet(sub.id).data, lambda x: x.lifecycle_state == 'AVAILABLE', 'subnet')
    st.update(vcn_id=vcn.id, subnet_id=sub.id)
    save(st)


def instance(c, st, cid):
    vm = find(all_of(c.compute.list_instances, cid), VM)
    if vm:
        return vm
    ads = [a.name for a in c.iam_region.list_availability_domains(c.tenancy).data]
    N = oci.core.models
    # Always Free shapes first; a small paid shape if neither has capacity.
    for shape, cfgd, arch in [('VM.Standard.A1.Flex', N.LaunchInstanceShapeConfigDetails(ocpus=1, memory_in_gbs=1), 'aarch64'),
                              ('VM.Standard.E2.1.Micro', None, 'x86'),
                              ('VM.Standard.E5.Flex', N.LaunchInstanceShapeConfigDetails(ocpus=1, memory_in_gbs=1), 'x86')]:
        imgs = [i for i in c.compute.list_images(c.tenancy, operating_system='Oracle Linux', operating_system_version='9',
                shape=shape, sort_by='TIMECREATED', sort_order='DESC').data if 'GPU' not in i.display_name]
        if not imgs:
            continue
        for ad in ads:
            try:
                say(f'Launching {VM} ({shape}) in {ad}')
                vm = c.compute.launch_instance(N.LaunchInstanceDetails(
                    compartment_id=cid, availability_domain=ad, display_name=VM, shape=shape, shape_config=cfgd,
                    source_details=N.InstanceSourceViaImageDetails(image_id=imgs[0].id, boot_volume_size_in_gbs=50),
                    create_vnic_details=N.CreateVnicDetails(subnet_id=st['subnet_id'], assign_public_ip=False),
                    freeform_tags=TAGS)).data
                vm = wait(lambda: c.compute.get_instance(vm.id).data,
                          lambda x: x.lifecycle_state in ('RUNNING', 'TERMINATED'), VM, every=10, timeout=900)
                if vm.lifecycle_state == 'RUNNING':
                    st['instance_id'] = vm.id
                    save(st)
                    return vm
            except oci.exceptions.ServiceError as e:
                if e.status in (500, 400) and ('capacity' in (e.message or '').lower() or e.code in ('InternalError', 'LimitExceeded')):
                    say(f'  no capacity or limit for {shape} in {ad}; trying the next option')
                    continue
                raise
    sys.exit('Could not launch a VM in any availability domain. Try another region, or try again later.')


# ---------------------------------------------------------------- checks and reset
def ready(c, quiet=False):
    st = load()
    if not st.get('lab_id'):
        sys.exit('Nothing built yet; run build.')
    pols = {p.name: p for p in all_of(c.iam.list_policies, st['lab_id']) if p.lifecycle_state == 'ACTIVE'}
    user = c.iam.get_user(st['user_id']).data
    member_of = {m.group_id for m in all_of(c.iam.list_user_group_memberships, c.tenancy, user_id=user.id)
                 if m.lifecycle_state == 'ACTIVE'}
    vm = c.compute.get_instance(st['instance_id']).data if st.get('instance_id') else None
    checks = {
        'asha_active': user.lifecycle_state == 'ACTIVE',
        'asha_in_both_groups': set(st['groups'].values()) <= member_of,
        'support_policy_present': SUPPORT_POLICY in pols and pols[SUPPORT_POLICY].statements == [SUPPORT_STATEMENT],
        'read_policy_absent': 'Summit-DevTeam-Read' not in pols,
        'deny_policy_absent': 'Summit-Deny-Power' not in pols,
        'vm_running': bool(vm) and vm.lifecycle_state == 'RUNNING',
    }
    if not quiet:
        for k, v in checks.items():
            print(f"  {'OK  ' if v else 'FAIL'} {k}")
        print('IAM lab: STARTING STATE' if all(checks.values()) else 'IAM lab: not at the starting state (run reset)')
    return all(checks.values())


def reset(c):
    st = load()
    for p in all_of(c.iam.list_policies, st['lab_id']):
        if p.name in LAB_POLICIES and p.lifecycle_state == 'ACTIVE':
            c.iam.delete_policy(p.id)
            say(f'Deleted policy {p.name}')
    user_id = st['user_id']
    for g, gid in st['groups'].items():
        if not all_of(c.iam.list_user_group_memberships, c.tenancy, user_id=user_id, group_id=gid):
            c.iam.add_user_to_group(oci.identity.models.AddUserToGroupDetails(user_id=user_id, group_id=gid))
            say(f'Restored {USER} in {g}')
    if not find(all_of(c.iam.list_policies, st['lab_id']), SUPPORT_POLICY):
        c.iam.create_policy(oci.identity.models.CreatePolicyDetails(compartment_id=st['lab_id'], name=SUPPORT_POLICY,
            statements=[SUPPORT_STATEMENT], freeform_tags=TAGS, description='Left over from an old support task (lab story)'))
        say(f'Restored {SUPPORT_POLICY}')
    vm = c.compute.get_instance(st['instance_id']).data
    if vm.lifecycle_state == 'STOPPED':
        c.compute.instance_action(vm.id, 'START')
        say(f'Starting {VM}')
        wait(lambda: c.compute.get_instance(vm.id).data, lambda x: x.lifecycle_state == 'RUNNING', VM, every=10)
    time.sleep(10)
    return ready(c)


def gone(fetch, label, done_states=('TERMINATED', 'DELETED')):
    """Wait until an object is deleted: a terminal state or 404 both count as gone."""
    for _ in range(120):
        try:
            if fetch().lifecycle_state in done_states:
                return
        except oci.exceptions.ServiceError as e:
            if e.status == 404:
                return
            raise
        time.sleep(15)
    sys.exit(f'Timed out deleting {label}; rerun teardown.')


def quietly(fn, *a, **k):
    """Delete calls are safe to repeat: ignore 404 (already gone) and 409 (already being deleted)."""
    try:
        return fn(*a, **k)
    except oci.exceptions.ServiceError as e:
        if e.status in (404, 409) or (e.code == 'NotAllowed' and 'non active compartment' in str(e.message)):
            return None  # already gone, or already being deleted
        raise


def teardown(c):
    st = load()
    if not st.get('lab_id'):
        say('Nothing to remove.')
        return
    if st.get('instance_id'):
        quietly(c.compute.terminate_instance, st['instance_id'], preserve_boot_volume=False)
        say(f'Terminating {VM}')
        gone(lambda: c.compute.get_instance(st['instance_id']).data, VM)
    if st.get('subnet_id'):
        quietly(c.vn.delete_subnet, st['subnet_id'])
        gone(lambda: c.vn.get_subnet(st['subnet_id']).data, 'subnet')
    if st.get('vcn_id'):
        quietly(c.vn.delete_vcn, st['vcn_id'])
        gone(lambda: c.vn.get_vcn(st['vcn_id']).data, 'VCN')
    for p in all_of(c.iam.list_policies, st['lab_id']):
        if p.lifecycle_state == 'ACTIVE' and (ours(p) or p.name in LAB_POLICIES):
            quietly(c.iam.delete_policy, p.id)
            say(f'Deleted policy {p.name}')
    try:
        c.iam.get_user(st['user_id'])
        for m in all_of(c.iam.list_user_group_memberships, c.tenancy, user_id=st['user_id']):
            if m.group_id in st['groups'].values():
                quietly(c.iam.remove_user_from_group, m.id)
        quietly(c.iam.delete_user, st['user_id'])
        say(f'Deleted user {USER}')
    except oci.exceptions.ServiceError as e:
        if e.status != 404:
            raise
    for g, gid in st['groups'].items():
        quietly(c.iam.delete_group, gid)
        say(f'Deleted group {g}')
    time.sleep(20)
    quietly(c.iam.delete_compartment, st['child_id'])
    try:
        child = c.iam.get_compartment(st['child_id']).data.lifecycle_state
    except oci.exceptions.ServiceError as e:
        if e.status != 404:
            raise
        child = 'DELETED'
    if child != 'DELETED':
        # OCI can take 30 minutes or more to delete a compartment, and the parent waits for its child.
        say(f'Deleting compartment {CHILD}: OCI finishes this in the background.')
        say(f'All lab resources are gone. To delete the empty compartment {LAB} too, run this')
        say('teardown again in about an hour. An empty compartment costs nothing.')
        say('If you created the Summit Retail Portal app or the SummitPortalUsers group, delete them in the Console.')
        return
    quietly(c.iam.delete_compartment, st['lab_id'])
    say(f'Deleting compartment {LAB} (OCI finishes this in the background)')
    (STATE / 'state.json').unlink(missing_ok=True)
    say('Teardown complete. If you created the Summit Retail Portal app or the SummitPortalUsers group, delete them in the Console.')


def friendly(e):
    if getattr(e, 'code', '') == 'CompartmentAlreadyExists':
        return ('A compartment with this name still exists, probably because an earlier teardown is still deleting it. '
                'OCI keeps the name until the deletion finishes. Wait 15-30 minutes and run the same command again.')
    return None


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('command', choices=['build', 'asha-password', 'ready', 'reset', 'teardown'])
    ap.add_argument('--asha-email')
    ap.add_argument('--parent')
    ap.add_argument('--region')
    ap.add_argument('--yes', action='store_true')
    a = ap.parse_args()
    if a.command == 'asha-password':
        st = load()
        if not st.get('asha_password'):
            sys.exit('No password yet; run build first.')
        print(f"Asha signs in as: {USER}   one-time password: {st['asha_password']}")
        print('Use a private browser window. The Console asks her to choose a new password at first sign-in.')
        return
    c = Cloud(a.region or load().get('region'))
    if a.command == 'build':
        ok = build(c, a.asha_email, a.parent)
    elif a.command == 'ready':
        ok = ready(c)
    elif a.command == 'reset':
        ok = reset(c)
    else:
        if not a.yes:
            sys.exit('teardown deletes the lab user, groups, policies, VM and compartments; rerun with --yes')
        teardown(c)
        ok = True
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    try:
        main()
    except oci.exceptions.ServiceError as e:
        msg = friendly(e)
        if not msg:
            raise
        sys.exit(msg)
