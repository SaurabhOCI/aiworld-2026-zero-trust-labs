# Self-paced lab: Incident 1, too much access (IAM deny + SSO)

Run in OCI Cloud Shell, in your home region:

    python3 lab.py build --asha-email you+asha@example.com
    python3 lab.py asha-password
    python3 lab.py ready
    python3 lab.py reset
    python3 lab.py teardown --yes

Follow the activity guide OUT1015_SelfPaced_IAM_SSO_Activity_Guide.
